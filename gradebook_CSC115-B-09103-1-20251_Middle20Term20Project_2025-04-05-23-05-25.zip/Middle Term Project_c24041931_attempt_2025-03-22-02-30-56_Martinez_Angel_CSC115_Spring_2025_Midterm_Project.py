
def show_student_information():
    name = "Angel Martinez"
    email  = "alm933@miami.edu"
    major = "Computer Science"
    course = "CSC 115"
    semester = "Spring Semester"
    print(name,email,major,course,semester, sep="\n")
    main()


    #My full name, email, major, course name, and semester in respective variables.

def show_roman_binary_number():
    selected_number = int(input("Enter a number from 1 to 10: "))
    while (selected_number <1) or (selected_number>10):
        selected_number = int(input("Error, input not accepted.\nEnter a number from 1 to 10: "))
        #vaildating if input is number between 1-10.

    #decision structures for the numbers 1-10. bin() function for binary, x[2:] to remove b0 from the bin() function.
    if (selected_number==1) :
        x = bin(1)
        print("Number 1:\t Roman: I\t Binary:", x[2:])
    elif (selected_number==2) :
        x = bin(2)
        print("Number 2:\t Roman: II\t Binary:", x[2:])
    elif (selected_number==3) :
        x = bin(3)
        print("Number 3:\t Roman: III\t Binary:", x[2:])
    elif (selected_number==4) :
        x = bin(4)
        print("Number 4:\t Roman: IV\t Binary:", x[2:])
    elif (selected_number==5) :
        x = bin(5)
        print("Number 5:\t Roman: V\t Binary:", x[2:])
    elif (selected_number==6) :
        x = bin(6)
        print("Number 6:\t Roman: VI\t Binary:", x[2:])
    elif (selected_number==7) :
        x = bin(7)
        print("Number 7:\t Roman: VII\t Binary:", x[2:])
    elif (selected_number==8) :
        x = bin(8)
        print("Number 8:\t Roman: VIII\t Binary:", x[2:])
    elif (selected_number==9) :
        x = bin(9)
        print("Number 9:\t Roman: IX\t Binary:", x[2:])
    else:
        x = bin(10)
        print("Number 10:\t Roman: X\t Binary:", x[2:])
    main()


def show_population():
    #validating that starting population is at least 1.
    starting_population= int(input("Enter the starting amount of Organisms: "))
    while(starting_population<1):
        starting_population = int(input("Invalid input. Re-enter the starting amount of Organisms: "))

    #validating that the increase is between 1 and 100 and then making it a percentage.
    daily_increase = float(input("Enter the average daily increase: "))
    while (daily_increase < 1) or (daily_increase >100):
        daily_increase = float(input("Invalid input. Re-enter the average daily increase: "))
    daily_increase = daily_increase/100

    # validating the numbers is between 2 and 30.
    days= int(input("Enter the number of days to multiply: "))
    while (days<2) or (days>30):
        days = int(input("Invalid input. Re-enter the number of days to multiply: "))

    #intiallizing a variable
    population= starting_population
    #printing the header of the table
    print("Date Approximate\t Population")
    #for loop that goes through the calculations of the changing population per day.
    for n in range (1,days+1):
        print(n,"\t"*5,f"{population:.2f}"  )
        population_increase  = population * daily_increase
        population= population_increase+ population

    print("\n")
    main()







#menu for choices, validates the user input before continuing. Other functions call this function to return to the menu.
def main():
    menu_option = int(input("\nWelcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals\n"
              "Binary and Predict Population. Enter option 1 to display Student Information. Enter option 2 to\n"
              "display Roman Numerals and Binary. Enter option 3 to Predict the Population. Enter option 9 to\n"
              "Exit the program. "))

    while (menu_option != 1) and (menu_option != 2) and (menu_option != 3) and (menu_option != 4) and (menu_option != 9):
        menu_option = int(input("\nError, Please enter valid option. Enter option 1 to display Student Information. Enter option 2 to\n"
                  "display Roman Numerals and Binary. Enter option 3 to Predict the Population. Enter option 9 to\n"
                  "Exit the program. "))

    if(menu_option==1):
        show_student_information()

    elif (menu_option==2):
        show_roman_binary_number()

    elif (menu_option==3):
        show_population()

    elif (menu_option==9):
        #Ending program option. Ends program completely.
        print("Ending Program.")
        exit(0)

main()