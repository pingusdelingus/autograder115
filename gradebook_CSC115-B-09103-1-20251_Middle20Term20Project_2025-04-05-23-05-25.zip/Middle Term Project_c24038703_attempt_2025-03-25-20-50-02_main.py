 #This section of code happens when the user chooses option 1. The show_student information
#function displays shows my name, my email, my major, my course, and the current semester
def show_student_information():
    print("\nStudent Information:")
    print("Ritchie Sabalvaro")
    print("Email: rjs650@miami.edu")
    print("Major: Finance/Global Business")
    print("Course: CSC115")
    print("Semester: Spring 2025")

#This function is for the Roman Numerals and Binary function.
def get_valid_input(prompt, min_val, max_val):
    #This variable establishes the entered value in num.
    num = input(prompt)
    #This while statement establishes that the input is an integer and not an invalid input.
    #Int num also converts the string into an integer.
    #This also ensures that the input is valid within the given range.
    while not num.isdigit() or not (min_val <= int(num) <= max_val):
        #If the input is invalid, the program asks the user to re-enter a value.
        print(f"Input is not valid. Re-enter a number between {min_val} and {max_val}.")
        num = input(prompt)
        #After a valid input is received, this line converts the string into an integer and returns it to the caller.
    return int(num)

#This is the function line for the roman numerals and binary function code.
def show_roman_binary_number():
#This line refers to how the numbers convert to roman numerals
    roman_numerals = {1: "I", 2: "II", 3: "III", 4: "IV", 5: "V", 6: "VI", 7: "VII", 8: "VIII", 9: "IX", 10: "X"}
#This line calls the get valid input function and ensures that the input is valid within the given range
    num = get_valid_input("\nEnter a number (1-10): ", 1, 10)
#This line prints the roman numerals
    print(f"Roman Numeral: {roman_numerals[num]}")
#This line  converts the num into its binary representation.
    print(f"Binary Value: {bin(num)[2:]}")

#This line is the for the function of show_population.
def show_population():
    #This line establishes the variable start_num as the input in which the function will use while making sure
    #input is in the valid range using get_valid_input.
    start_num = get_valid_input("\nEnter a starting number for organisms between 1-100: ", 1, 100)
    #This line establishes daily_increase as the user input while using the get_valid_input function to make sure the
    #input is valid and within the range.
    daily_increase = get_valid_input("Enter the average daily increase percentage 1-100: ", 1, 100)
    # This line establishes days as the user input while using the get_valid_input function to make sure the
    # input is valid and within the range.
    days = get_valid_input("Enter the number of days between 2-30: ", 2, 30)
    #This line prints the word day and approximate population
    print("\nDay\tApproximate Population")
    #This line establishes population equal to the variable start_num.
    population = start_num
    #this for loop ensures that the loop keeps running from 1, until 1 more than the number of days.
    for day in range(1, days + 1):
        #This prints the day and population as well as formatting the population to two decimal places.
        print(f"{day}\t{population:.2f}")
        #This line calculates the increasing population based on percentage and multiplies the population by the growth.
        #This then adds this growth to population and updates it for the following day.
        population += population * (daily_increase / 100)

#This is defined as the main function
def main():
    #This establishes the variable choice as the user input
    choice = ""
    #This while loop establishes that the loop will keep running as long as the input isn't 9.
    while choice != "9":
        #This is the welcome statement which automatically runs .
        print("\nWelcome to the CSC115 Midterm Project Program")
        #This print statement prints the following words.
        print("1. Display Student Information")
        #This print statement prints the following words.
        print("2. Display Roman Numerals and Binary")
        #This print statement prints the following words.
        print("3. Predict the Population")
        #This print statement prints the following words.
        print("9. Exit the program")
        #This establishes the variable choice to the users input.
        choice = input("Enter your choice: ")
        #This if statement calls the show student information function.
        if choice == '1':
            show_student_information()
            # This elif statement calls the show roman_binary number function.
        elif choice == '2':
            show_roman_binary_number()
            # This elif statement calls the show population function.
        elif choice == '3':
            show_population()
            # This elif returns the following statement saying that they are exiting the program.
        elif choice == '9':
            print("Exiting the program. Goodbye!")
        #This else statement runs and returns text telling the user their choice isnt valid
        else:
            print("Invalid choice. Please enter a valid option.")

#This line ensures that the code is run directly within the file and prevents unintended execution of the code.
if __name__ == "__main__":
    main()
