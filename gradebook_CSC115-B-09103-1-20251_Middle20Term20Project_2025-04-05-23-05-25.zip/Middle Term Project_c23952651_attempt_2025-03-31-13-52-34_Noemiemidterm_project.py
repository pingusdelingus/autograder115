# Function to display student information
def show_student_information():
    print("\n--- Student Information: ---")
    print("Full Name: Noemie Semerjian")
    print("Email: nes126@miami.edu")
    print("Major: Health Science")
    print("Course: CSC115 - Python Programming for Everyone")
    print("Semester: Spring 2025\n")


# Function to convert a number (1-10) to Roman Numerals and Binary
def show_roman_binary_number():
    print("\n" + "-" * 50)
    print("Here is the ROMAN NUMERALS and BINARY CONVERTER")
    print("-" * 50)

# Ask user for a number between 1 and 10, repeat until valid input
    number = int(input("Enter a number between 1 and 10: "))
    while number < 1 or number > 10:
        number = int(input("Invalid input. Please re-enter a number between 1 and 10: "))

# Dictionary for numbers and their corresponding roman number
    roman_numerals = {
        1: 'I', 2: 'II', 3: 'III', 4: 'IV', 5: 'V',
        6: 'VI', 7: 'VII', 8: 'VIII', 9: 'IX', 10: 'X'
    }

# Convert number to binary
    binary = ""
    num = number
    # Loop until the number becomes 0
    while num > 0:
        # Get the remainder when num is divided by 2, add that bit to the front of the string
        binary = str(num % 2) + binary
        # Divide by 2 to move to the next bit
        num = num // 2

# Display results
    print("Number:", number)
    print("Roman Numeral:", roman_numerals[number])
    print("Binary:", binary)


# Function to predict population
def show_population():
    print("\n" + "-" * 50)
    print("Here is the PREDICTION POPULATION")
    print("\n" + "-" * 50)

# Input validation for starting organisms, must be an integer and >= 1
    starting_organisms_input = input("Enter the number of Starting Organisms: ")
    index_organisms = 0
    # Loop through each character to ensure input contains only digits between 0-9
    # if not, ask the user to re-enter value
    while index_organisms < len(starting_organisms_input):
        if starting_organisms_input[index_organisms] < "0" or starting_organisms_input[index_organisms] > "9":
            starting_organisms_input = input("Invalid Input. Please re-enter the number of Starting Organisms: ")
            index_organisms = 0
        else:
            # Move to the next character
            index_organisms = index_organisms + 1

    # Convert validated string into float
    starting_organisms = float(starting_organisms_input)
    # Check that it is >= 1, if not, ask user to enter valid number
    while starting_organisms < 1:
        starting_organisms = float(input("Invalid Input. Please re-enter the number of Starting Organisms: "))

# Ask user to enter average daily increase, initialize index and counter for input validation
    average_input = input("Please input the Average Daily Increase input: ")
    index_average = 0
    dot_count = 0

    # Loop through each character in the input to validate the float number
    while index_average < len(average_input):
        if average_input[index_average] == ".":
            # Count decimal points
            dot_count = dot_count + 1
        elif average_input[index_average] < "0" or average_input[index_average] > "9":
            # If it's not a digit or a period, invalid
            dot_count = 2
        # Move to the next character
        index_average = index_average + 1

    # If the input has more than one decimal point or any invalid character,
    # ask user to re-enter a valid float
    while dot_count > 1:
        average_input = input("Invalid Input. Please re-enter the Average Daily Increase input: ")
        index_average = 0
        dot_count = 0
        while index_average < len(average_input):
            if average_input[index_average] == ".":
                dot_count = dot_count + 1
            elif average_input[index_average] < "0" or average_input[index_average] > "9":
                dot_count = 2
            index_average = index_average + 1

    # Convert the validated input to a float value
    average_daily_increase = float(average_input)

    # Make sure value is between 1 and 100
    while average_daily_increase < 1 or average_daily_increase > 100:
        average_daily_increase = float(input("Invalid Input. Please re-enter the Average Daily Increase input: "))

# Enter number of days to multiply
    days_input = input("Please input the Number of days to multiply input: ")
    index_days = 0
    # Validate that the characters are digits, if not, ask user to re-enter valid number
    while index_days < len(days_input):
        if days_input[index_days] < "0" or days_input[index_days] > "9":
            days_input = input("Invalid Input. Please re-enter the Number of days to multiply input: ")
            index_days = 0
        else:
            index_days = index_days + 1

    # Convert validated string to integer
    days_to_multiply = int(days_input)

    # Make sure number of days is within valid range (2-30), if out of range, re-enter
    while days_to_multiply < 2 or days_to_multiply > 30:
        days_to_multiply = int(input("Invalid Input. Please re-enter the Number of days to multiply input: "))

    # Format
    print("Day Approximate \t\tPopulation")
    # Initialize population with starting number of organisms
    population = starting_organisms
    # Loop through each day from 1 to total number of days user inputs
    for day in range(1, days_to_multiply + 1):
        # Print, format
        print(f"{day}\t\t\t\t\t{format(population, '.2f')}")
        # Update population by increasing according to the average daily increase
        population = population + (population * (average_daily_increase / 100))


# Function to run the program with the menu
def main():
    menu = (
        ("-" * 50) + "\n"
        "Welcome to the CSC115 Midterm Project Program.\n"
        "This Python program displays Roman Numerals and Predict Population.\n"
        "Enter option 1 to display Student Information.\n"
        "Enter option 2 to display Roman Numerals.\n"
        "Enter option 3 to Predict Population.\n"
        "Enter option 9 to Exit the program.\n"
    )

    print(menu)

# Menu loop until user chooses to exit (option 9)
    choice = int(input("Please enter a choice (1, 2, 3, or 9): "))
    while choice != 9:
        if choice == 1:
            show_student_information()
        elif choice == 2:
            show_roman_binary_number()
        elif choice == 3:
            show_population()
        else:
            print("Invalid Option. Please re-enter: ")

        print(menu)
        choice = int(input("Please enter a choice (1, 2, 3, or 9): "))

    print("You selected option 9 which exits the program. Goodbye.")
    print("Program ended.")

if __name__ == '__main__':
    main()
