def student_information():
    print("Full Name: Aakash Singh")
    print("Email: axs8965@miami.edu")
    print("Major: Psychology & Philosophy")
    print("Course: CSC 115 - Python Programming for Everyone")
    print("Semester: Spring 2025")


def roman_binary_number():
    roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    binary_values = ["1", "10", "11", "100", "101", "110", "111", "1000", "1001", "1010"]
    while True:
        try:
            num = int(input("Enter a number (1-10): "))
            if 1 <= num <= 10:
                print(f"Roman Numeral: {roman_numerals[num - 1]}")
                print(f"Binary Value: {binary_values[num - 1]}")
                break
            else:
                print("Error: Number must be between 1 and 10.")
        except ValueError:
            print("Error: Invalid input. Please enter a number between 1 and 10.")


def population():
    while True:
        try:
            starting_organisms = int(input("Enter starting number of organisms: "))
            if starting_organisms <= 0:
                print("Error: Starting number must be greater than 0.")
                continue
            break
        except ValueError:
            print("Error: Invalid input. Enter a positive integer.")

    while True:
        try:
            average_increase = float(input("Enter average daily increase (percentage): "))
            if average_increase < 1 or average_increase > 100:
                print("Error: Average daily increase must be between 1 and 100.")
                continue
            break
        except ValueError:
            print("Error: Invalid input. Enter a number between 1 and 100.")

    while True:
        try:
            days = int(input("Enter number of days to multiply (2-30): "))
            if days < 2 or days > 30:
                print("Error: Days must be between 2 and 30.")
                continue
            break
        except ValueError:
            print("Error: Invalid input. Enter an integer between 2 and 30.")

    print("\nDay Approximate | Population")
    print("----------------------------------")
    population = starting_organisms
    for day in range(1, days + 1):
        print(f"{day:<15} | {population:.2f}")
        population += population * (average_increase / 100)


def main():
    while True:
        print("\nWelcome to the CSC115 Midterm Project Program! This Python program displays Roman Numerals, Binary and Predict Population.")
        print("Enter 1 to Display Student Information")
        print("Enter 2 Roman Numerals and Binary Numbers")
        print("Enter 3 to Predict Population")
        print("Enter 9 to Exit the Program")

        choice = input("Enter your choice: ")
        if choice == "1":
            student_information()
        elif choice == "2":
            roman_binary_number()
        elif choice == "3":
            population()
        elif choice == "9":
            print("This is the end of the program. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a valid option.")

name = "main"
if name == "main":
    main()