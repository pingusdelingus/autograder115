def show_student_information():
    #Displays student information.
    print("\nStudent Information:")
    print("Full Name: Janeen Llaurado")
    print("Email: jxl2685@miami.edu")
    print("Major: Health Sciences")
    print("Course: CSC115")
    print("Semester: Spring 2025\n")


def show_roman_binary_number():
    #Asks for a number (1-10) and shows its Roman numeral and binary value.
    #Keeps asking until a valid number is entered.
    roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    binary_values = ["1", "10", "11", "100", "101", "110", "111", "1000", "1001", "1010"]

    num = 0
    while not (1 <= num <= 10): #Validates input
        try:
            num = int(input("Enter a number (1-10): "))
            if not (1 <= num <= 10): #Checks if within range
                print("Error: Number must be between 1 and 10.")
        except ValueError: #Handles non-integer inputs
            print("Error: Invalid input. Please enter a number between 1 and 10.")

    print(f"Roman Numeral: {roman_numerals[num - 1]}")
    print(f"Binary Value: {binary_values[num - 1]}\n")


def show_population():
    #Predicts population growth based on user input.
    #Input is validated before calculations.
    start_population = -1
    while start_population <= 0: #Validates input
        try:
            start_population = int(input("Enter starting number of organisms: "))
            if start_population <= 0: #Checks if within range
                print("Error: Population must be greater than zero.")
        except ValueError: #Handles non-integer values
            print("Error: Please enter a valid positive integer.")

    #Get and validate daily increase percentage
    daily_increase = 0
    while not (1 <= daily_increase <= 100): #Validates input
        try:
            daily_increase = float(input("Enter average daily population increase (%): "))
            if not (1 <= daily_increase <= 100): #Checks if within range
                print("Error: Daily increase must be between 1 and 100.")
        except ValueError: #Handles non-integer inputs
            print("Error: Please enter a valid percentage.")

    #Get and validate number of days
    days = 0
    while not (2 <= days <= 30): #Validates input
        try:
            days = int(input("Enter number of days (2-30): "))
            if not (2 <= days <= 30): #Checks if within range
                print("Error: Days must be between 2 and 30.")
        except ValueError: #Handles non-integer inputs
            print("Error: Please enter a valid number of days.")

    #Displays table header
    print("\nDay\tApproximate Population")
    print("---------------------------------")
    #Displays population for day 1
    print(f"{'1':<5} {start_population:>15.2f}")

#Calculates and displays population for each day
    for day in range(2, days + 1):
        start_population += start_population * (daily_increase / 100)
        print(f"{day:<5} {start_population:>15.2f}")
    print()


def main():
    #Displays the menu and keeps looping until the user chooses to exit
    choice = ""
    while choice != "9": #Loop until user exits
        print("""Welcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals 
/ Binary and Predict Population. Enter option 1 to display Student Information. Enter option 2 to 
display Roman Numerals and Binary. Enter option 3 to Predict the Population. Enter option 9 to 
Exit the program.""")

        choice = input("Enter your choice: ")

        #Calls correct function based on input
        if choice == "1":
            show_student_information()
        elif choice == "2":
            show_roman_binary_number()
        elif choice == "3":
            show_population()
        elif choice == "9":
            print("Exiting program. Goodbye!")
        else:
            print("Invalid choice. Please enter a valid option.")


# Runs the program
if __name__ == "__main__":
    main()
