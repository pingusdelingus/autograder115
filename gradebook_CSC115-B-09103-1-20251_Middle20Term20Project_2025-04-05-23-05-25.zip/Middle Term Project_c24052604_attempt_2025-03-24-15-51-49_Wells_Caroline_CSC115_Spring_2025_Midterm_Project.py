#student information
#When the user selects option 1 then the program displays: your full name, email, major, course
#name, and semester.

def show_student_information():
    print("Caroline Wells, \n cbw94@miami.edu,\n major: Health Science,\n CSC115,\n Spring 2025")

#binary and roman numerals
#when user selects option 2 program should ask for input and
#display the roman numeral and binary value of input

def show_roman_binary_number():
    number = int(input("Enter a number within the range of 1 to 10: "))
    while number < 1 or number > 10:
        number = int(input("Enter a number within the range of 1 to 10: "))

    if number == 1:
        return "I 1"
    elif number == 2:
        return "II 10"
    elif number == 3:
        return "III 11"
    elif number == 4:
        return "IV 100"
    elif number == 5:
        return "V 101"
    elif number == 6:
        return "VI 110"
    elif number == 7:
        return "VII 111"
    elif number == 8:
        return "VIII 1000"
    elif number == 9:
        return "IX 1001"
    elif number == 10:
        return "X 1010"

#population
#when user selects option 3. the program will predict the approximate size of a population of
#organisms. the program will take an input of the starting number of organisms, average daily population
#increase, and the number of days the organisms will multiply

def show_population():
    organisms = float(input("Please enter the number of Starting Organisms: "))
    while organisms < 0:
        organisms = float(input("Invalid input. Please re-enter number of Starting Organisms: "))

    daily = int(input("Please enter the Average Daily Increase: "))
    while daily<1 or daily > 100:
        daily = int(input("Invalid input. Please re-enter Average Daily Increase: "))

    days = int(input("Please enter the Number of Days to Multiply: "))
    while days<2 or days>30:
        days = int(input("Invalid input. Please re-enter Number of Days to Multiply: "))

    for day in range(days):
        print(day+1, f"{organisms:.2f}")
        organisms = organisms + daily/100 * organisms

def main():
    choice = int(input(" Welcome to the CSC 115 Midterm Project Program. This Python program displays Roman Numerals\n"
                       "/Binary and Predict Population. Enter option 1 to display Student Information. Enter option 2 to display\n "
                       "Roman numerals and Binary. Enter option 3 to Predict the Population. Enter option 9 to exit the program: "))

    while choice !=9:
        if choice == 1:
            show_student_information()
        elif choice == 2:
            print(show_roman_binary_number())
        elif choice == 3:
            show_population()
        choice = int(input(" Welcome to the CSC 115 Midterm Project Program. This Python program displays Roman numerals\n"
                           "/Binary and Predict Population. Enter option 1 to display Student Information. Enter option 2 to display\n "
                           "Roman numerals and Binary. Enter option 3 to Predict the Population. Enter option 9 to exit the program: "))
main()



