def display_menu():
    """ Function to display the menu options """
    print("\n===== Main Menu =====")
    print("Welcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals / Binary and Predict Population.")
    print("Enter option 1 to display Student Information.")
    print("Enter option 2 to display Roman Numerals and Binary.")
    print("Enter option 3 to Predict the Population")
    print("Enter option 9 to Exit the program.")


def show_student_information():
    print("\nStudent Information:")
    print("Full Name: Sebastian Vergara")
    print("Email: srv45@miami.edu")
    print("Major: Health Sciences")
    print("Course: Software Engineering")
    print("Semester: Spring 2025\n")


def show_roman_binary_number():
    """ Function to convert numbers to Roman and Binary """
    num = int(input("Enter a number (1-10) to convert: "))

    # Dictionary for Roman Numerals
    roman_dict = {1: "I", 2: "II", 3: "III", 4: "IV", 5: "V",
                  6: "VI", 7: "VII", 8: "VIII", 9: "IX", 10: "X"}

    if 1 <= num <= 10:
        print(f"Roman Numeral: {roman_dict[num]}")
        print(f"Binary Representation: {bin(num)[2:]}")
    else:
        print("Please enter a number between 1 and 10!")


def show_population():
    """ Function to predict population growth """
    current_population = int(input("Enter current population: "))
    growth_rate = float(input("Enter growth rate (%): "))
    years = int(input("Enter number of years: "))

    for i in range(1, years + 1):
        current_population += int(current_population * (growth_rate / 100))
        print(f"Year {i}: Estimated Population = {current_population}")


def main():
    """ Main function to control the menu (Without while True) """

    # Use a for loop with a large limit instead of `while True`
    for _ in range(100):  # Arbitrary large number to allow multiple attempts
        display_menu()
        choice = input("Enter your choice (1-9): ")

        if choice == '1':
            show_student_information()
        elif choice == '2':
            show_roman_binary_number()
        elif choice == '3':
            show_population()
        elif choice == '9':
            print("Exiting program. Goodbye!")
            return  # Ends the function, stopping the program
        else:
            print("Invalid choice, please try again!")


# Run the program
main()
