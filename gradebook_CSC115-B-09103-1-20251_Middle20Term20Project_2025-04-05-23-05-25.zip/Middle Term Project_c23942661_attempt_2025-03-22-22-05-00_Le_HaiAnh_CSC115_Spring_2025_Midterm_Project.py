def show_student_information():
    print("Full name: Hai Anh Le")
    print("Email: ahl95@miami.edu")
    print("Major: Neuroscience")
    print("Class: CSC115 Spring 2025")

def show_roman_binary_number():
    roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    binary_values = ["1", "10", "11", "100", "101", "110", "111", "1000", "1001", "1010"]
    number = input("Enter a number between 1 and 10: ")

    if number.isdigit():
        num = int(number)
        if 1 <= num <= 10:
            print(f"Roman Numeral: {roman_numerals[num-1]}")
            print(f"Binary Value: {binary_values[num-1]}")
        else:
            print("Error: Please enter a number between 1 and 10.")
            return show_roman_binary_number()
    else:
        print("Error: Please enter a valid number.")
        return show_roman_binary_number()


def show_population():
    starting_population = int(input("Enter the starting number of organisms: "))
    if starting_population < 0:
        print("Error: Starting number of organisms must be a positive integer.")
        starting_population = input("Enter the starting number of organisms: ")
    else:
        starting_population = int(starting_population)

    daily_increase = int(input("Enter the average daily population increase (1-100): "))
    if daily_increase < 1 or daily_increase > 100:
        print("Error: Please enter a value between 1 and 100.")
        daily_increase = input("Enter the average daily population increase (1-100): ")
    else:
        daily_increase = int(daily_increase)

    days = int(input("Enter the number of days to multiply (2-30): "))
    if days < 2 or days > 30:
        print("Error: Please enter a value between 2 and 30.")
        days = input("Enter the number of days to multiply (2-30): ")
    else:
        day = int(days)

    print("\nDay\tApproximate Population")
    population = starting_population
    for day in range(1, days + 1):
        population += population * (daily_increase / 100)
        print(f"{day}\t{population:.2f}")

def main():
    print("\nWelcome to the CSC115 Midterm Project Program.")
    print("This Python program displays Roman Numerals / Binary and Predict Population.")
    print("Enter option 1 to display Student Information.")
    print("Enter option 2 to display Roman Numerals and Binary.")
    print("Enter option 3 to Predict the Population.")
    print("Enter option 9 to Exit the program.")
    user_option = input("Please enter 1/2/3/9: ")
    if user_option == "1":
        show_student_information()
    elif user_option == '2':
        show_roman_binary_number()
    elif user_option == '3':
        show_population()
    elif user_option == '9':
        print("Exiting program. Goodbye.")
    else:
        print("Error: Invalid option. Please select a valid option (1, 2, 3, 9).")
        return main()
main()


