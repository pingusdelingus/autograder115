def main():

    mainInput = 0
    while(mainInput != 9):
        print("Welcome to the CSC115 Midterm Project Program. \n"
              "This Python program displays Roman Numerals/ Binary and Predict Population. \n"
              "Enter option 1 to display Student Information. \n"
              "Enter option 2 to display Roman Numerals and Binary. \n"
              "Enter option 3 to Predict the Population. \n"
              "Enter option 9 to Exit the program.")

        mainInput = int(input())

        if mainInput == 1:
            show_student_information()
        elif mainInput ==2:
            show_roman_binary_number()
        elif mainInput ==3:
            show_population()

    print("You have successfully exited. Thank you for playing!")


def show_student_information():
    print("\n_______________________________________")
    print("Full name: Galit Sencianes")
    print("Email: gxs1911@miami.edu")
    print("Major: Health Science")
    print("Course: Python Programming for Everyone (CSC 115)")
    print("Semester: Spring 2025")
    print("_______________________________________ \n")


def show_roman_binary_number():

    numInput = int(input("Enter a binary number (from 1-10):"))
    romanNumerals= ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X']
    binaryNumbers= [1, 10, 11, 100, 101, 110, 111, 1000, 1001, 1010]

    while numInput < 1 or numInput > 10:
        print("ERROR. Invalid Input!")
        numInput = int(input("Re-enter a binary number (from 1-10):"))

    print("\n_______________________________________")
    if numInput == 1:
        print(f"Roman Numeral: {romanNumerals[0]}")
        print(f"Binary Number: {binaryNumbers[0]}")
    elif numInput == 2:
        print(f"Roman Numeral: {romanNumerals[1]}")
        print(f"Binary Number: {binaryNumbers[1]}")
    elif numInput == 3:
        print(f"Roman Numeral: {romanNumerals[2]}")
        print(f"Binary Number: {binaryNumbers[2]}")
    elif numInput == 4:
        print(f"Roman Numeral: {romanNumerals[3]}")
        print(f"Binary Number: {binaryNumbers[3]}")
    elif numInput == 5:
        print(f"Roman Numeral: {romanNumerals[4]}")
        print(f"Binary Number: {binaryNumbers[4]}")
    elif numInput == 6:
        print(f"Roman Numeral: {romanNumerals[5]}")
        print(f"Binary Number: {binaryNumbers[5]}")
    elif numInput == 7:
        print(f"Roman Numeral: {romanNumerals[6]}")
        print(f"Binary Number: {binaryNumbers[6]}")
    elif numInput == 8:
        print(f"Roman Numeral: {romanNumerals[7]}")
        print(f"Binary Number: {binaryNumbers[7]}")
    elif numInput == 9:
        print(f"Roman Numeral: {romanNumerals[8]}")
        print(f"Binary Number: {binaryNumbers[8]}")
    elif numInput == 10:
        print(f"Roman Numeral: {romanNumerals[9]}")
        print(f"Binary Number: {binaryNumbers[9]}")

    print("_______________________________________ \n")



def show_population():
    numOfOrganisms = int(input("Enter the starting number of organisms: "))
    while numOfOrganisms < 0:
        print("Invalid input.")
        numOfOrganisms = int(input("Please re-enter the starting number of organisms:"))

    avgPopIncrease = float(input("Enter the average population increase (%): "))
    while avgPopIncrease < 1 or avgPopIncrease > 100:
        print("Invalid input.")
        avgPopIncrease = float(input("Please re-enter the average population increase (%): "))


    numDays = int(input("The number of days the organism will be left to multiply: "))
    while numDays < 2 or numDays > 30:
        print("Invalid input.")
        numDays = int(input("Please re-enter the number of days the organism will be left to multiply: "))



    # Calculate and display population
    print("\nDay\t|\tApproximate Population")
    print("--------------------------------")
    population = numOfOrganisms

    for day in range(1, numDays + 1):
        print(f"{day}\t|\t{population:.2f}")
        population += population * (avgPopIncrease / 100)



main()
