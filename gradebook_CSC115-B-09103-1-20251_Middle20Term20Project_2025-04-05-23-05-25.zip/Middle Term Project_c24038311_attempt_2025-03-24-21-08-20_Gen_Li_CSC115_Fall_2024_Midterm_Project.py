def show_student_information():
    """Display student information when option 1 is selected."""
    print("\nStudent Information:")
    print("Name: Your Full Name")
    print("Email: your.email@example.com")
    print("Major: Computer Science")
    print("Course: CSC115")
    print("Semester: Fall 2024")


def show_roman_binary_number():
    """Convert a number (1-10) to Roman numeral and binary when option 2 is selected."""
    roman_numerals = {
        1: 'I', 2: 'II', 3: 'III', 4: 'IV', 5: 'V',
        6: 'VI', 7: 'VII', 8: 'VIII', 9: 'IX', 10: 'X'
    }


    valid_input = False
    attempts = 0
    while attempts < 3 and not valid_input:
        user_input = input("\nEnter a number between 1 and 10: ").strip()
        if user_input.isdigit():
            num = int(user_input)
            if 1 <= num <= 10:
                print(f"\nRoman Numeral: {roman_numerals[num]}")
                print(f"Binary Value: {bin(num)[2:]}")
                valid_input = True
            else:
                print("Error: Number must be between 1 and 10.")
        else:
            print("Error: Please enter a valid number.")
        attempts += 1

    if not valid_input:
        print("Maximum attempts reached. Returning to menu.")


def show_population():
    """Predict population growth with validated inputs when option 3 is selected."""

    start_org = 0
    valid_start = False
    attempts = 0
    while attempts < 3 and not valid_start:
        start_org = input("\nEnter starting number of organisms (≥1): ").strip()
        if start_org.isdigit():
            start_org = int(start_org)
            if start_org >= 1:
                valid_start = True
            else:
                print("Error: Must be at least 1 organism.")
        else:
            print("Error: Please enter a valid number.")
        attempts += 1

    if not valid_start:
        print("Maximum attempts reached. Returning to menu.")
        return


    daily_inc = 0.0
    valid_inc = False
    attempts = 0
    while attempts < 3 and not valid_inc:
        daily_inc = input("Enter average daily increase % (1-100): ").strip()
        if daily_inc.replace('.', '').is_digit():
            daily_inc = float(daily_inc)
            if 1 <= daily_inc <= 100:
                valid_inc = True
            else:
                print("Error: Must be between 1-100%.")
        else:
            print("Error: Please enter a valid number.")
        attempts += 1

    if not valid_inc:
        print("Maximum attempts reached. Returning to menu.")
        return


    days = 0
    valid_days = False
    attempts = 0
    while attempts < 3 and not valid_days:
        days = input("Enter number of days to multiply (2-30): ").strip()
        if days.isdigit():
            days = int(days)
            if 2 <= days <= 30:
                valid_days = True
            else:
                print("Error: Must be between 2-30 days.")
        else:
            print("Error: Please enter a valid number.")
        attempts += 1

    if not valid_days:
        print("Maximum attempts reached. Returning to menu.")
        return


    population = float(start_org)
    print("\nDay\tPopulation")
    print("----------------")
    for day in range(1, days + 1):
        if day > 1:
            population += population * (daily_inc / 100)
        print(f"{day}\t{population:.2f}")


def main():
    """Main function to display menu and handle user options."""
    running = True
    while running:
        print("\nWelcome to the CSC115 Midterm Project Program.")
        print("1. Display Student Information")
        print("2. Display Roman Numerals and Binary")
        print("3. Predict Population")
        print("9. Exit Program")

        choice = input("Enter your option: ").strip()

        if choice == '1':
            show_student_information()
        elif choice == '2':
            show_roman_binary_number()
        elif choice == '3':
            show_population()
        elif choice == '9':
            print("Exiting program. Goodbye!")
            running = False
        else:
            print("Invalid option. Please try again.")


if __name__ == "__main__":
    main()


