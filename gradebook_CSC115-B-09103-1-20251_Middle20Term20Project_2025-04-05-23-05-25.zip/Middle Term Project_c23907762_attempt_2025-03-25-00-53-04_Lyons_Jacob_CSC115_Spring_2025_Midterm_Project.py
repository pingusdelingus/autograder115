#define student info function
def show_student_information():
    #print out user information
    print('\nname: Jacob Lyons\n'
          'email: jal1018@miami.edu\n'
          'major: Broadcast Journalism\n'
          'course: CSC 115\n'
          'semester: Spring 25\n')

#define the romany and binary function
def show_roman_binary_number():
    #validation of a number between 1 and 10
    num = int(input('Enter a number between 1 and 10: '))
    while num > 10 or num <= 0:
        num = int(input('Invalid input. Please enter a new number: '))
    #determine which numeral and binary value to print based on user's input
    if num == 1:
        print('Roman Numeral: I\n'
              'Binary Value: 1\n')
    elif num == 2:
        print('Roman Numeral: II\n'
              'Binary Value: 10\n')
    elif num == 3:
        print('Roman Numeral: III\n'
              'Binary Value: 11\n')
    elif num == 4:
        print('Roman Numeral: IV\n'
              'Binary Value: 100\n')
    elif num == 5:
        print('Roman Numeral: V\n'
              'Binary Value: 101\n')
    elif num == 6:
        print('Roman Numeral: VI\n'
              'Binary Value: 110\n')
    elif num == 7:
        print('Roman Numeral: VII\n'
              'Binary Value: 111\n')
    elif num == 8:
        print('Roman Numeral: VIII\n'
              'Binary Value: 1000\n')
    elif num == 9:
        print('Roman Numeral: IX\n'
              'Binary Value: 1001\n')
    elif num == 10:
        print('Roman Numeral: X\n'
              'Binary Value: 1010\n')

#define population function
def show_population():
    #validation for the three inputs
    population = float(input('Enter the number of starting organisms: '))
    while population < 1:
        population = float(input('Invalid Input. Please re-enter the starting number of organisms: '))

    daily_increase = float(input('Enter the Average Daily Increase percentage: '))
    while daily_increase < 1 or daily_increase > 100:
        daily_increase = float(input('Invalid Input. Please re-enter the Average Daily Increase percentage: '))
    #convert user input number into a decimal percentage
    percentage = (daily_increase/100) + 1

    days_multiply = int(input('Please enter the number of days to multiply: '))
    while days_multiply < 2 or days_multiply > 30:
        days_multiply = int(input('Invalid Input. Please re-enter the number of days to multiply:'))

    #print the header for the output
    print('\n'
          'Day Approximate        Population\n'
          '--------------------------------------------------')
    #print the days and population numbers
    for i in range (1,days_multiply+1):
        print(f'\t{i}.\t\t\t\t\t{population:.2f}')
        population = population * percentage

#define the main function
def main():
    user_selection = 0
    #validation of user menu inputs
    while user_selection not in(1,2,3,9):
        user_selection = int(input('Welcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals/Binary and Predict Population.\n'
                   'Enter option 1 to display Student Information.\n'
                    'Enter option 2 to display Roman Numerals and Binary.\n'
                    'Enter option 3 to Predict the Population.\n'
                    'Enter option 9 to Exit the Program.\n'
                    'Enter number here: '))
        #menu selection based on user's input
        if user_selection == 1:
            show_student_information()
            user_selection = 0
        elif user_selection == 2:
            show_roman_binary_number()
            user_selection = 0
        elif user_selection == 3:
            show_population()
            user_selection = 0
        #program breaks once user types 9
        elif user_selection == 9:
            break

main()