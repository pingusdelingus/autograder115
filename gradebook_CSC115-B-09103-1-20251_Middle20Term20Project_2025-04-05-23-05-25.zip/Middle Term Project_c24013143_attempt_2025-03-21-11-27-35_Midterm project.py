# Mazin_Adrian_CSC115_Fall_2024_Midterm_Project.py
# CSC115 Fall 2024 Midterm Project
# This program displays menu options for: Student Information, Roman Numerals/Binary,
# and Population Prediction.

def show_student_information():
    """
    Displays student information including full name, email, major, course name, and semester.
    No parameters required.
    No return value.
    """
    print("\n----- Student Information -----")
    print("Full Name: Adrian Mazin")
    print("Email: axm8684@miami.edu")
    print("Major: Sports Administration")
    print("Course Name: CSC115")
    print("Semester: Spring 2025")
    print("-------------------------------\n")


def show_roman_binary_number():
    """
    Prompts the user to enter a number from 1 to 10.
    Displays the Roman numeral and binary equivalent of the input number.
    Input validation ensures only numbers 1-10 are accepted.
    No parameters required.
    No return value.
    """
    print("\n----- Roman Numerals & Binary Numbers -----")

    # Define Roman numerals and binary values for numbers 1-10
    roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    binary_values = ["1", "10", "11", "100", "101", "110", "111", "1000", "1001", "1010"]

    valid_input = False
    while not valid_input:
        try:
            # Prompt user for input
            user_input = input("Enter a number between 1 and 10: ")

            # Validate input is a number
            number = int(user_input)

            # Validate input is within range
            if 1 <= number <= 10:
                valid_input = True

                # Display Roman numeral and binary value
                print(f"Input Number: {number}")
                print(f"Roman Numeral: {roman_numerals[number - 1]}")
                print(f"Binary Value: {binary_values[number - 1]}")
            else:
                print("Error: Number must be between 1 and 10. Please try again.")
        except ValueError:
            print("Error: Invalid input. Please enter a number.")

    print("-------------------------------------------\n")


def show_population():
    """
    Predicts the approximate size of a population of organisms.
    Prompts user for starting number of organisms, daily increase percentage,
    and number of days to multiply.
    Performs input validation and displays population growth table.
    No parameters required.
    No return value.
    """
    print("\n----- Population Prediction -----")

    # Get and validate starting number of organisms
    valid_start = False
    while not valid_start:
        try:
            starting_number = float(input("Enter the starting number of organisms: "))
            if starting_number > 0:
                valid_start = True
            else:
                print("Error: Starting number must be positive. Please try again.")
        except ValueError:
            print("Error: Invalid input. Please enter a number.")

    # Get and validate average daily increase percentage
    valid_increase = False
    while not valid_increase:
        try:
            increase = float(input("Enter the average daily increase (1-100%): "))
            if 1 <= increase <= 100:
                valid_increase = True
            else:
                print("Error: Average daily increase must be between 1 and 100. Please try again.")
        except ValueError:
            print("Error: Invalid input. Please enter a number.")

    # Get and validate number of days
    valid_days = False
    while not valid_days:
        try:
            days = int(input("Enter the number of days to multiply (2-30): "))
            if 2 <= days <= 30:
                valid_days = True
            else:
                print("Error: Number of days must be between 2 and 30. Please try again.")
        except ValueError:
            print("Error: Invalid input. Please enter a number.")

    # Convert percentage to decimal
    increase_decimal = increase / 100

    # Display table header
    print("\nDay\tApproximate Population")
    print("---------------------------------")

    # Calculate and display population for each day
    population = starting_number
    for day in range(1, days + 1):
        print(f"{day}.\t{population:.2f}")
        population += population * increase_decimal

    print("-------------------------------------------\n")


def main():
    """
    Main function that displays the menu options and processes user selections.
    Continues looping until user selects option 9 to exit.
    No parameters required.
    No return value.
    """
    option = 0

    while option != 9:
        # Display menu options
        print("\nWelcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals")
        print("/ Binary and Predict Population. Enter option 1 to display Student Information. Enter option 2 to")
        print("display Roman Numerals and Binary. Enter option 3 to Predict the Population. Enter option 9 to")
        print("Exit the program.")

        # Get user option
        try:
            option = int(input("Enter your option (1, 2, 3, or 9): "))

            # Process user option
            if option == 1:
                show_student_information()
            elif option == 2:
                show_roman_binary_number()
            elif option == 3:
                show_population()
            elif option == 9:
                print("Thank you for using the CSC115 Midterm Project Program. Goodbye!")
            else:
                print("Error: Invalid option. Please enter 1, 2, 3, or 9.")
        except ValueError:
            print("Error: Invalid input. Please enter a number.")


# Call the main function to start the program
if __name__ == "__main__":
    main()
    