# Function to display student information
def show_student_information():
    print("Student Information:")
    print("Full Name: Smilte Sazanskyte")
    print("Email: sxs4727@miami.edu")
    print("Major: Computer Science")
    print("Course: CSC115 - Introduction to Programming")
    print("Semester: Spring 2025")

# Function to display Roman numerals and binary values for numbers 1-10
def show_roman_binary_number():
    # Lists to store Roman numeral and binary values corresponding to numbers 1-10
    roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    binary_values = ["1", "10", "11", "100", "101", "110", "111", "1000", "1001", "1010"]

    num = 0 # Initialize user input variable
    while not 1 <= num <= 10:
        try:
            num = int(input("Enter a number between 1 and 10: "))
            if not (1 <= num <= 10): # Ensures number is within range
                print("Invalid input. Please enter a number between 1 and 10.")
        except ValueError:
            print("Invalid input. Please enter a valid integer.") # Handles non-integer inputs

    print(f"Roman Numeral: {roman_numerals[num - 1]}")
    print(f"Binary Value: {binary_values[num - 1]}")

# Function to predict population growth over a given number of days
def show_population():
    # Input validation for starting population (must be greater than 0)
    start_population = -1 # Initialize with an invalid value to enter the loop
    while start_population <= 0:
        try:
            start_population = int(input("Enter starting number of organisms: "))
            if start_population <= 0:
                print("Error: Starting population must be greater than 0.")
        except ValueError:
            print("Error: Invalid input. Enter a positive integer.") # Handles non-integer inputs

    # Input validation for daily increase percentage (must be between 1 and 100)
    daily_increase = 0 # Initialize with an invalid value
    while not 1 <= daily_increase <= 100:
        try:
            daily_increase = float(input("Enter average daily increase (1-100%): "))
            if not 1 <= daily_increase <= 100:
                print("Error: Enter a percentage between 1 and 100.")
        except ValueError:
            print("Error: Invalid input. Enter a valid percentage.") # Handles non-numeric inputs

    # Input validation for number of days (must be between 2 and 30)
    days = 0 # Initialize with an invalid value
    while not 2 <= days <= 30:
        try:
            days = int(input("Enter number of days to multiply (2-30): "))
            if not (2 <= days <= 30):
                print("Error: Enter a value between 2 and 30.")
        except ValueError:
            print("Error: Invalid input. Enter a valid number.") # Handles non-integer inputs

    # Display population growth table
    print("\nDay\tApproximate Population")
    print("--------------------------------")
    population = start_population
    print(f"1\t{population:.2f}") # Display initial population for day 1
    # Calculate and display population for each day
    for day in range(2, days+1):
        population += population * (daily_increase / 100)
        print(f"{day}\t{population:.2f}")

def main():
    option = 0 # Initialize with an invalid value
    while option != 9: # Continuously loops until the user selects option 9
        print("Welcome to the CSC115 Midterm Project Program.")
        print("This Python program displays Roman Numerals/ Binary and Predict Population.")
        print("Enter option 1 to display Student Information.")
        print("Enter option 2 to display Roman Numerals and Binary.")
        print("Enter option 3 to Predict the Population.")
        print("Enter option 9 to Exit the program.")

        try:
            option = int(input("Please select an option (1, 2, 3, or 9): "))
            if option == 1:
                show_student_information()
            elif option == 2:
                show_roman_binary_number()
            elif option == 3:
                show_population()
            elif option == 9:
                print("Exiting the program. Goodbye!")
            else:
                print("Invalid option. Please try again.") # Handles invalid menu selections
        except ValueError:
            print("Invalid input. Please enter a valid menu option.")  # Handles non-integer inputs

if __name__ == '__main__':
    main()