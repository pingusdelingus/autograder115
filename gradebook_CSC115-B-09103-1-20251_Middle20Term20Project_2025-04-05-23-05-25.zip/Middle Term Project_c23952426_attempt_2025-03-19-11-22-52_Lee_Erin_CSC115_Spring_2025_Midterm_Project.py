# CSC115 Fall 2024 Midterm Project
# Name: [Erin]
# Email: [esl111@miaim.edu]
# Major: [Health Science]
# Course: CSC115
# Semester: Spring 2025

def show_student_information():
    print("\nStudent Information:")
    print("Name: Erin Lee")
    print("Email: esl111@miami.edu")
    print("Major: Health Science")
    print("Course: CSC115")
    print("Semester: Spring 2025")


def show_roman_binary_number():
    roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    num = input("\nEnter a number (1-10): ")
    if int(num):
        num = int(num)
        if 1 <= num <= 10:
            binary_value = ""
            n = num
            while n > 0:
                binary_value = str(n % 2) + binary_value
                n = n // 2
            print(f"Roman Numeral: {roman_numerals[num - 1]}")
            print(f"Binary Value: {binary_value}")
            return
    print("Error - Please enter a valid number between 1 and 10")
    show_roman_binary_number()


def show_population():
    start_population= int(input("\nEnter starting number of organisms: "))
    while start_population <= 0:
        print("Error - the starting number of organisms must be greater than 0")
        start_population = int(input("Enter starting number of organisms: "))

    daily_increase = int(input("Enter average daily increase (1-100%): "))
    while daily_increase < 1 or daily_increase > 100:
        print("Error - the daily increase percentage must be between 1 and 100")
        daily_increase = int(input("Enter average daily increase (1-100%): "))

    days= int(input("Enter number of days (2-30): "))
    while days < 2 or days > 30:
        print("Error - the number of days entered must be between 2 and 30")
        days = int(input("Enter number of days (2-30): "))

    print("\nDay Approximate  Population")
    population =start_population
    for day in range(1, days + 1):
        print(f"{day}                {population:.2f}")
        population += population * (daily_increase / 100)


def main():
    choice = ""
    while choice != "9":
        print("\nWelcome to the CSC115 Midterm Project Program")
        print("Enter Option 1 to Display Student Information")
        print("Enter Option 2 to Display Roman Numerals and Binary")
        print("Enter Option 3 to Predict Population")
        print("Enter Option 9 to Exit the Program")

        choice = input("Enter an option: ")
        if choice == "1":
            show_student_information()
        elif choice == "2":
            show_roman_binary_number()
        elif choice == "3":
            show_population()
        elif choice != "9":
            print("Error - Invalid choice, please enter 1, 2, 3, or 9")


main()
