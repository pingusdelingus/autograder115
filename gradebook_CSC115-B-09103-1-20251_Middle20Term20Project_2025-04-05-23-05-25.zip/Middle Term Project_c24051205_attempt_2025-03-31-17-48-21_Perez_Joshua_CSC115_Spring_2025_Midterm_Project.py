def show_student_information():
    print('\nFull Name: Joshua Perez\n'
          'Email: Jxp2645@miami.edu\n'
          'Major: Data Science & AI/Quantitative Economics\n'
          'Course Name: CSC115\n'
          'Semester: Spring 2025')

def show_roman_binary_number():
    roman_numerals = {1: 'I', 2: 'II', 3: 'III', 4: 'IV', 5: 'V', 6: 'VI', 7: 'VII', 8: 'VIII', 9: 'IX', 10: 'X'}

    num = 0
    while num < 1 or num > 10:
        try:
            num = int(input('\nEnter a number 1-10: '))
            if num < 1 or num > 10:
                print('Invalid Input! Please enter a number between 1 and 10.')
        except ValueError:
            print('Invalid Input! Please enter a valid number.')
            num = 0

    print(f'{'Input Number':^15}{'Roman Numeral':^15}{'Binary Value':^15}')
    print(f'{num:^15}{roman_numerals[num]:^15}{bin(num)[2:]:^15}')

def show_population():
    start_population = -1
    while start_population <= 0:
        try:
            start_population = int(input('\nEnter starting number of organisms: '))
            if start_population <= 0:
                print('Invalid Input! The starting number must be greater than 0.')
        except ValueError:
            print('Invalid Input! Please enter a valid number.')
            start_population = -1

    daily_increase = 0
    while daily_increase < 1 or daily_increase > 100:
        try:
            daily_increase = float(input('Enter average daily increase percentage (1-100): '))
            if daily_increase < 1 or daily_increase > 100:
                print('Invalid Input! The Daily Increase must be between 1 and 100')
        except ValueError:
            print('Invalid Input! Please enter a valid number.')
            daily_increase = 0

    days = 0
    while days < 2 or days > 30:
        try:
            days = int(input('Enter number of days (2-30): '))
            if days < 2 or days > 30:
                print('Invalid Input! Days must be between 2 and 30.')
        except ValueError:
            print('Invalid Input! Please enter a valid number.')
            days = 0

    print(f'{'\nDay Approximate':^12}{'Population':^20}')
    population = start_population
    for day in range(1, days+1):
        print(f'{day:^12}{population:^20.2f}')
        population += (population * (daily_increase / 100))

def main():
    choice = ''
    while choice != '9':
        print('\nWelcome to the CSC115 Midterm Project Program.\nThis Python program displays Roman Numerals / Binary and Predicts Population.')
        print('Enter option 1 to display Student Information')
        print('Enter option 2 to display Roman Numerals and Binary')
        print('Enter option 3 to Predict the Population')
        print('Enter option 9 to Exit the program.')

        choice = input('Enter an option: ')
        if choice == '1':
            show_student_information()
        elif choice == '2':
            show_roman_binary_number()
        elif choice == '3':
            show_population()
        elif choice == '9':
            print('Exiting the program. Goodbye.')
        else:
            print('Invalid option! Please enter a valid menu option.')

main()