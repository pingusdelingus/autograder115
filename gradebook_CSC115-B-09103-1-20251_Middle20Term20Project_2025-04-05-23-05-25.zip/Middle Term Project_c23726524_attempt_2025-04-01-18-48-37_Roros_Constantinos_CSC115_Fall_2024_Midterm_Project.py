# Constantinos Roros
# crr147@miami.edu
# Economics Major
# CSC115 – Introduction to Programming
# Spring 2025 Midterm Project

# Function to display student information
def show_student_information():
    print("\n--- Student Information ---")
    print("Full Name: Constantinos Roros")
    print("Email: crr147@miami.edu")
    print("Major: Economics")
    print("Course: CSC115 – Introduction to Programming")
    print("Semester: Spring 2025")
    print("-----------------------------\n")

# Function to display Roman numeral and binary value of a number from 1 to 10
def show_roman_binary_number():
    roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    print("\n--- Roman Numerals and Binary Conversion ---")

    # Ask for input and validate it
    number = input("Enter a number between 1 and 10: ")
    while not number.isdigit() or not (1 <= int(number) <= 10):
        print("Invalid input! Please enter a number from 1 to 10 only.")
        number = input("Re-enter a number between 1 and 10: ")

    # Convert input to integer
    number = int(number)

    # Get corresponding Roman numeral and binary value
    roman = roman_numerals[number - 1]
    binary = bin(number)[2:]  # Convert to binary and remove '0b' prefix

    # Display results
    print(f"Roman Numeral: {roman}")
    print(f"Binary Value: {binary}\n")

# Function to predict population over a number of days
def show_population():
    print("\n--- Population Growth Prediction ---")

    # Ask and validate starting number of organisms (must be >= 1)
    start = input("Enter the starting number of organisms (must be >= 1): ")
    while not start.isdigit() or int(start) < 1:
        print("Invalid input! Starting number must be 1 or more.")
        start = input("Re-enter the starting number of organisms: ")
    start = float(start)

    # Ask and validate average daily increase percentage (1–100)
    increase = input("Enter average daily population increase (1–100): ")
    while not increase.isdigit() or not (1 <= int(increase) <= 100):
        print("Invalid input! Daily increase must be between 1 and 100.")
        increase = input("Re-enter the average daily increase: ")
    increase = float(increase)

    # Ask and validate number of days (2–30)
    days = input("Enter number of days the organisms will multiply (2–30): ")
    while not days.isdigit() or not (2 <= int(days) <= 30):
        print("Invalid input! Number of days must be between 2 and 30.")
        days = input("Re-enter the number of days: ")
    days = int(days)

    # Display population growth table
    print("\nDay\tApproximate Population")
    print("-------------------------------")
    population = start
    for day in range(1, days + 1):
        print(f"{day}.\t{population:.2f}")
        population += population * (increase / 100)
    print()

# Main function to display menu and handle user input
def main():
    while True:
        # Display menu
        print("Welcome to the CSC115 Midterm Project Program.")
        print("This Python program displays Roman Numerals / Binary and Predict Population.")
        print("Enter option 1 to display Student Information.")
        print("Enter option 2 to display Roman Numerals and Binary.")
        print("Enter option 3 to Predict the Population.")
        print("Enter option 9 to Exit the program.\n")

        # Get user option and call the appropriate function
        option = input("Enter your option: ")
        if option == "1":
            show_student_information()
        elif option == "2":
            show_roman_binary_number()
        elif option == "3":
            show_population()
        elif option == "9":
            print("Exiting the program. Goodbye!")
            break
        else:
            print("Invalid option. Please select from the menu.\n")

# Start the program
main()
