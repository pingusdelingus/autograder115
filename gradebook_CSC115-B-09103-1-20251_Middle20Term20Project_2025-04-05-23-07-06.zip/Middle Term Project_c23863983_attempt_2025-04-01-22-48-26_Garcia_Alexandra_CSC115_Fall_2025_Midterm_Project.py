def show_student_information():
    # Displays student information
    print("\nStudent Information")
    print("---------------------")
    print("Full Name: Alexandra Garcia")  # Replace with actual name
    print("Email: axg5587@miami.edu")  # Replace with actual email
    print("Major: Health Science")  # Replace with actual major
    print("Course: CSC115")
    print("Semester: Fall 2025")
    print("---------------------\n")


def show_roman_binary_number():
    # Ask the user to enter a number between 1 and 10 and display the Roman numeral & binary value
    roman_numerals = {1: "I", 2: "II", 3: "III", 4: "IV", 5: "V",
                      6: "VI", 7: "VII", 8: "VIII", 9: "IX", 10: "X"}

    binary_values = {1: "1", 2: "10", 3: "11", 4: "100", 5: "101",
                     6: "110", 7: "111", 8: "1000", 9: "1001", 10: "1010"}

    user_input = None
    while user_input is None:
        try:
            number = int(input("Enter a number between 1 and 10: "))
            if 1 <= number <= 10:
                user_input = number
            else:
                print("Invalid input. Please enter a number between 1 and 10.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    print(f"Roman Numeral: {roman_numerals[user_input]}")
    print(f"Binary Value: {binary_values[user_input]}\n")


def show_population():
    # Predicts population growth based on user input

    start_organisms = None
    while start_organisms is None:
        try:
            num = int(input("Enter the starting number of organisms (minimum 1): "))
            if num >= 1:
                start_organisms = num
            else:
                print("Invalid input. Starting organisms must be at least 1.")
        except ValueError:
            print("Invalid input. Please enter a valid integer.")

    daily_increase = None
    while daily_increase is None:
        try:
            percent = float(input("Enter the average daily increase percentage (1-100): "))
            if 1 <= percent <= 100:
                daily_increase = percent
            else:
                print("Invalid input. Daily increase must be between 1% and 100%.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    days = None
    while days is None:
        try:
            num_days = int(input("Enter the number of days to multiply (2-30): "))
            if 2 <= num_days <= 30:
                days = num_days
            else:
                print("Invalid input. Days must be between 2 and 30.")
        except ValueError:
            print("Invalid input. Please enter a valid integer.")

    # Display table header
    print("\nDay\tApproximate Population")
    print("----------------------------")

    population = start_organisms  # Initialize population
    for day in range(1, days + 1):
        print(f"{day}\t{population:.2f}")  # Format output to 2 decimal places
        population += population * (daily_increase / 100)  # Update population

    print("----------------------------\n")


def main():
    # Main function to display the menu and handle user choices

    choice = None
    while choice != "9":
        print("\nWelcome to the CSC115 Midterm Project Program.")
        print("This Python program displays Roman Numerals / Binary and Predict Population.")
        print("1. Display Student Information")
        print("2. Display Roman Numerals and Binary")
        print("3. Predict Population")
        print("9. Exit the program")

        choice = input("Enter your choice: ")

        if choice == "1":
            show_student_information()
        elif choice == "2":
            show_roman_binary_number()
        elif choice == "3":
            show_population()
        elif choice == "9":
            print("Exiting the program. Goodbye!")
        else:
            print("Invalid choice. Please enter a valid option (1, 2, 3, or 9).")


# Run the program
if __name__ == "__main__":
    main()

