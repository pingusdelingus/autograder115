
def show_student_information():
    print("Daniel Guzman") #Function prints all the information in five lines when called
    print("ddg73@miami.edu")
    print("Computer Science Major")
    print("CSC115 - Python Programming for Everyone")
    print("2nd Semester of Freshman Year")
    print("~" * 90) #Better visually for output formatting

def show_roman_binary_number():
    try: #Validates user input as integer
        roman_choice = int(input("Enter a number within the range of 1 to 10: ")) #Stores user's choice
        if 1<= roman_choice <= 10: #Validates input to be within the range
            input_number = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] #List created to store all possible numbers
            roman_numeral = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'] #List created to store all possible roman numerals
            binary_value = [1, 10, 11, 100, 101, 110, 111, 1000, 1001, 1010] #List created to store all possible binary values
            print(f"Input Number: {input_number[roman_choice-1]} | Roman Numeral: {roman_numeral[roman_choice-1]} | Binary Value: {binary_value[roman_choice-1]}") #Displays the selected input number, corresponding Roman numeral, and its binary value from the lists above using the user's choice
            print("~" * 90) #Better visually for output formatting
        else:
            print("Try again with a valid integer.")
            return show_roman_binary_number() #Loops back to the start of the function because of failure
    except ValueError:
        print("Not a valid integer. Try again.")
        return show_roman_binary_number() #Loops back to the start of the function because of failure

def organism_number():
    try: #Validates user input as float
        organism_input = float(input("Enter the starting number of organisms: ")) #Receives a float for percentage calculation
        if organism_input >= 0: #Checks for a negative number input and validates
            print("-" * 90) #Separates functions for better visual output
            return organism_input #Returns inputted value for later use and completes the function
        else:
            print("The number cannot be negative, try again.")
            return organism_number() #Loops back to the start of the function because of failure
    except ValueError:
        print("Enter a valid input. Try again.")
        return organism_number() #Loops back to the start of the function because of failure

def population_increase():
    try: #Validates user input as integer
        population_input = int(input("Enter a number as the percentage of the average daily population increase (without percent symbol): "))
        if 1 <= population_input <= 100: #Validates input to be within the range
            print("-" * 90) #Separates functions for better visual output
            return population_input #Returns inputted value for later use and completes the function
        else:
            print("Population percent needs to be in between 1-100. Try again.")
            return population_increase() #Loops back to the start of the function because of failure
    except ValueError:
        print("Enter a valid input. Try again.")
        return population_increase() #Loops back to the start of the function because of failure

def days_left():
    try: #Validates user input as integer
        days_input = int(input("Enter the number of days left that the organisms will be left to multiply: "))
        if 2 <= days_input <= 30: #Validates the number of days within range
            print("-" * 90) #Separates functions for better visual output
            return days_input #Returns inputted value for later use and completes the function
        else:
            print("Days left to multiply needs to be in between 2-30. Try again.")
            return days_left() #Loops back to the start of the function because of failure
    except ValueError:
        print("Enter a valid input. Try Again.")
        return days_left() #Loops back to the start of the function because of failure

def show_population():
    organisms = organism_number() #New variable in order to store the function's value for later use
    population_percent_increase = population_increase() / 100 #Converts user's input into a decimal (percent)
    days = days_left() #New variable to store value
    print("\n") #Adds spacing before displaying table
    print("  Day Approximate      Population")
    print("-" * 40)
    print(f"{1:>9} {organisms:>20.2f}") #Displays the first day's information (no equation applied)
    for day_count in range(2, days +1): #Creates a loop from day 2 up until the user's selected number of days
        organisms = organisms * (1 + population_percent_increase) #Applies population growth formula
        print(f"{day_count:>9} {organisms:>20.2f}") #Prints the day number and population within the range
    print("\n")
    print("~" * 90) #Better visually for output formatting

def main():
    try: #Validates user input as integer
        choice = int(input("Welcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals / Binary and Predict Population. \n"
                           "Enter option 1 to display Student Information. \n" 
                           "Enter option 2 to display Roman Numerals and Binary. \n"
                           "Enter option 3 to Predict the Population. \n"
                           "Enter option 9 to Exit the program. \n"
                           "> ")) #Spaces out initial input for better formatting and displays the information effectively
        print("~" * 90)
        if choice == 1:
            show_student_information() #Calls student information function
            return main() #loops the main function in order to get another user input after function completes
        elif choice == 2:
            show_roman_binary_number() #Calls Roman Numerals and Binary Numbers function
            return main() #loops the main function in order to get another user input after function completes
        elif choice == 3:
            show_population() #Calls Population function
            return main() #loops the main function in order to get another user input after function completes
        elif choice == 9:
            print("Thank you for using the program. Goodbye.") #Exits the program when option is selected
        else:
            print("Enter a valid integer. Try again.")
            return main() #Loops back to the start of the function because of failure
    except ValueError:
        print("That's not a valid integer. Please try again.")
        return main() #Loops back to the start of the function because of failure


main() #Calls main function to start the program




