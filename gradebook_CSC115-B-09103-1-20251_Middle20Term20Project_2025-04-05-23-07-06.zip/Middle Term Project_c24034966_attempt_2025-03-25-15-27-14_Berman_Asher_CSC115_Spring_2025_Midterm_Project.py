
def menu():#This function puts out the menu
    menu_option = input("Welcome to the CSC115 Midterm Project Program!\n"
                        " This Python program displays Roman Numerals/ Binary and Predict Population.\n"
                        " Enter 1 to display Student Information.\n"
                        " Enter 2 to display Roman Numerals and Binary.\n"
                        " Enter 3 to Predict the Population.\n"
                        " Enter 9 to Exit the program\n"
                        " Enter your choice here: ")
    #This input allows the menu to take input and move into one of the functions or exit
    if menu_option == '1':
        show_student_information()#Brings the user to the student information page
    elif menu_option == '2':
        show_roman_binary_number()#Takes the user to input and put out the roman numeral and binary number for the inputted value
    elif menu_option == '3':
        show_population()#Brings the user to the population growth function
    elif menu_option == '9':
        print('Thank you for using the project!')
        exit(0)#Exits the function upon request
    else:
        menu()#Validates the input by making the user input a valid input

def main():#Uses the menu function to seal everything up and simplify
    menu()

def show_student_information():
    print('Name: Asher Berman\n'
          'Email: alb495@miami.edu\n'
          'Major: Data Science & AI\n'
          'Course: CSC 115\n'
          'Semester: Spring 2025')
    menu()#Prints my information before returning the user to the menu

def show_roman_binary_number():
    displayed_number = int(input('Enter an integer from 1-10: '))
    if displayed_number <1 or displayed_number >10:
        print("Error. Please input an integer from 1 - 10.")
        show_roman_binary_number()#Validates the input with an if statement and asks the user to add a valid input
    elif displayed_number == 1:
        print(f'Binary: {bin(1)}\t Roman Numeral: I')
        menu()
    elif displayed_number == 2:
        print(f'Binary: {bin(2)}\t Roman Numeral: II')
        menu()
    elif displayed_number == 3:
        print(f'Binary: {bin(3)}\t Roman Numeral: III')
        menu()
    elif displayed_number == 4:
        print(f'Binary: {bin(4)}\t Roman Numeral: IV')
        menu()
    elif displayed_number == 5:
        print(f'Binary: {bin(5)}\t Roman Numeral: V')
        menu()
    elif displayed_number == 6:
        print(f'Binary: {bin(6)}\t Roman Numeral: VI')
        menu()
    elif displayed_number == 7:
        print(f'Binary: {bin(7)}\t Roman Numeral: VII')
        menu()
    elif displayed_number == 8:
        print(f'Binary: {bin(8)}\t Roman Numeral: VIII')
        menu()
    elif displayed_number == 9:
        print(f'Binary: {bin(9)}\t Roman Numeral: IX')
        menu()
    elif displayed_number == 10:
        print(f'Binary: {bin(10)}\t Roman Numeral: X')
        menu()#Each of the elif's display the binary and roman numeral before returning to the menu

def show_population():
    starting_population = int(input('Enter the starting population: '))
    percent_increase = float(input('Enter the daily percent increase: '))
    number_of_days = int(input("Enter the number of days: "))
    if starting_population <= 0:
        print('Error. Enter a valid positive number for starting population.')
        show_population()#Uses an if to validate the input of the starting population
    if percent_increase < 0:
        print('Error. Enter a valid number for percent increase.')
        show_population()#Uses an if to validate the input of the percent increase
    if number_of_days <=0:
        print('Error. Enter a valid positive number for number of days.')
        show_population()#Uses an if to validate the input of the number of days
    else:
        print(f'------------------------------------------------\n'
              f'Day \t\tApproximate Population')
        calculate_population(starting_population, percent_increase, number_of_days)#Passes the arguments stored in the variables above and calculates
        menu()#Upon completion brings the user back to the menu

def calculate_population(starting_population, percent_increase, number_of_days):#This is the function referenced just above that passes the arguments
    for day in range(1, number_of_days + 1): #Makes the program calculate teh days properly
        starting_population = starting_population * (1 + (percent_increase / 100))#Calculates the daily change in population
        print(f'{day}.\t\t{starting_population:.2f}')#Prints out the result


main()#Runs the overall program