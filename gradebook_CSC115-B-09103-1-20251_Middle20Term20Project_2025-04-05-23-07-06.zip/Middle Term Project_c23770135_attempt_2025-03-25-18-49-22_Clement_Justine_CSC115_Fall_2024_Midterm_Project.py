
def show_student_information():
    print("\nName: Justine Clement"
          "\nEmail: jrc346@miami.edu"
          "\nMajor: Health Science/Pre-Med"
          "\nCourse Name: CSC 115 - Python Programming for Everyone"
          "\nSemester: Spring 2025") # Display program menu

def show_roman_binary_number():
    num = int(input("\nEnter arabic number to convert\n"))  # Base 10 number to convert
    while num < 1 or num > 10:
        num = int(input("\nError. Please enter a number between 1 and 10\n"))   # Display error message if input is invalid
    roman = open("Roman.txt","r")  # Open roman numerals file with 0 to 10 in roman numerals
    binary = open("Binary.txt","r") # Open binary numbers file with 0 to 10 in binary
    for checkval in range(1,11):
        binarynum = (binary.readline()) # read binary number file lines from 0 to 10
        romannum = (roman.readline())   # read roman numerals file lines from 0 to 10
        if checkval == num:
            print("\nThe roman numeral corresponding to", num, "is", romannum)  # Print converted roman numerals
            print("\nThe binary number corresponding to", num, "is", binarynum) # Print converted binary number
    roman.close()   # Close Roman numerals file
    binary.close()  # Close binary numbers file

def show_population():
    population = float(input("\nStarting number of organisms: "))   # Population each year
    while population < 2 or population > 30:
        population = float(input("\nError. Please enter a starting number between 2 and 30: \n"))
    percpopchange = float(input("\nAverage percentage daily increase: "))   # Percentage change in population per year
    while percpopchange < 1 or percpopchange > 100:
        percpopchange = float(input("\nError. Please enter a daily increase between 1 and 100: \n"))
    popchange = percpopchange / 100 # Population annual change as a decimal
    numdays= int(input("\nNumber of days to multiply: "))
    print("\nDay \tApproximate Population")
    for i in range(1, numdays + 1):
        print(i, "\t\t\t{:.2f}".format(population)) # Print current population
        population = population * (1 + popchange)   # Calculate population after 1 year

def main():
    menu = ("\nWelcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals\n"
                       "/Binary and Predict Population. "
                       "\nEnter option 1 to display Student Information. "
                       "\nEnter option 2 to display Roman Numerals and Binary. "
                       "\nEnter option 3 to Predict the Population. \n"
                       "Enter option 9 to Exit the program.\n") # Define menu
    choice = int(input(menu))  # Print menu
    while choice != 9:
        if choice ==1:
            show_student_information()
        elif choice == 2:
            show_roman_binary_number()
        elif choice == 3:
            show_population()
        else:
            print("Invalid option, please enter 1,2,3, or 9")
        input("\nPress Enter to continue")
        choice = int(input(menu))

main()


