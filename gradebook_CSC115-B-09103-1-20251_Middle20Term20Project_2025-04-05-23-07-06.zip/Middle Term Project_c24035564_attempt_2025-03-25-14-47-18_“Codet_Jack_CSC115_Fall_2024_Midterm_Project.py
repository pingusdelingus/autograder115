# This function displays my student information when the user chooses option 1
def show_student_information():
    print("Full Name: Jack Codet")
    print("Email: jxc3221@miami.edu")
    print("Major: Data Science and AI")
    print("Course: CSC115 Python Programming")
    print("Semester: Spring 2025")


# This function displays the Roman numerals and binary values when the users chooses option 2
def show_roman_binary_number():
    # Gets the initial user input for a number between 1 and 10
    user_number = int(input("Enter a number between 1 and 10: "))

    # Validates that the input is within the range
    while user_number < 1 or user_number > 10:
        print("Error: Please enter a valid number between 1 and 10.")
        user_number = int(input("Enter a number between 1 and 10: "))

    # Display the Roman numeral and binary value based on the users input
    if user_number == 1:
        print("Roman Numeral: I")
        print("Binary Value: 1")
    elif user_number == 2:
        print("Roman Numeral: II")
        print("Binary Value: 10")
    elif user_number == 3:
        print("Roman Numeral: III")
        print("Binary Value: 11")
    elif user_number == 4:
        print("Roman Numeral: IV")
        print("Binary Value: 100")
    elif user_number == 5:
        print("Roman Numeral: V")
        print("Binary Value: 101")
    elif user_number == 6:
        print("Roman Numeral: VI")
        print("Binary Value: 110")
    elif user_number == 7:
        print("Roman Numeral: VII")
        print("Binary Value: 111")
    elif user_number == 8:
        print("Roman Numeral: VIII")
        print("Binary Value: 1000")
    elif user_number == 9:
        print("Roman Numeral: IX")
        print("Binary Value: 1001")
    elif user_number == 10:
        print("Roman Numeral: X")
        print("Binary Value: 1010")


# This function calculates and displays population growth when the user chooses option 3
def show_population():
    # Gets and validates starting number of organisms and makes sure it is positive
    starting_organisms = float(input("Enter the starting number of organisms: "))
    while starting_organisms < 0:
        print("Error: Starting number cannot be negative.")
        starting_organisms = float(input("Enter the starting number of organisms: "))

    # Gets and validates average daily increase between 1 and 100
    daily_increase = float(input("Enter the average daily population increase (as a percentage, e.g., 30): "))
    while daily_increase < 1 or daily_increase > 100:
        print("Error: Daily increase must be between 1 and 100.")
        daily_increase = float(input("Enter the average daily population increase (as a percentage, e.g., 30): "))

    # Converts percentage to a decimal for calculations
    daily_increase = daily_increase / 100

    # Gets and validates number of days that are between 2 and 30
    num_days = int(input("Enter the number of days to multiply (between 2 and 30): "))
    while num_days < 2 or num_days > 30:
        print("Error: Number of days must be between 2 and 30.")
        num_days = int(input("Enter the number of days to multiply (between 2 and 30): "))

    # Displays table header
    print("\nDay  Approximate Population")

    # Initializes day counter and population
    day = 1
    population = starting_organisms

    # Calculates and displays population for each day
    while day <= num_days:
        print(f"{day}.  {population:.2f}")

        # Updates population for next day
        population = population + (population * daily_increase)

        # Increment day counter
        day = day + 1


# Main function that displays the menu and manages the order
def main():
    choice = 0

    # Continues showing the menu until the user chooses to exit
    while choice != 9:
        # Displays menu options
        print("\nWelcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals")
        print("/ Binary and Predict Population. Enter option 1 to display Student Information. Enter option 2 to")
        print("display Roman Numerals and Binary. Enter option 3 to Predict the Population. Enter option 9 to")
        print("Exit the program.")

        # Gets user's menu choice
        choice_input = input("Enter your choice: ")

        # Process's user's choice
        if choice_input == "1":
            choice = 1
            show_student_information()
        elif choice_input == "2":
            choice = 2
            show_roman_binary_number()
        elif choice_input == "3":
            choice = 3
            show_population()
        elif choice_input == "9":
            choice = 9
            print("Thank you for using the program. Goodbye!")
        else:
            print("Invalid option. Please try again.")


# Calls the main function to start the program
if __name__ == "__main__":
    main()
