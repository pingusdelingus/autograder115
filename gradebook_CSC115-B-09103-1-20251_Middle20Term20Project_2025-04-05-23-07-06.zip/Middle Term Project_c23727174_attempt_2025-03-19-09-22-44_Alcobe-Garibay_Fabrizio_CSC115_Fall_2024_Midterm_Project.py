def show_student_information():
    """
    Displays the student information.
    Make sure to update the details below with your actual information.
    """
    print("Full Name: Fabrizio Alcobe-Garibay")
    print("Email: fxa475@miami.edu")
    print("Major: Economics")
    print("Course: CSC115")
    print("Semester: Spring 2025")
    print()  

def show_roman_binary_number():
    """
    Prompts the user to enter a number between 1 and 10.
    The input is validated (only numbers in range allowed).
    When valid, displays the corresponding Roman numeral and Binary value.
    
    The conversion is based on the following table:
      Input Number    Roman Numeral      Binary Value
             1             I                  1
             2             II                 10
             3             III                11
             4             IV                 100
             5             V                  101
             6             VI                 110
             7             VII                111
             8             VIII               1000
             9             IX                 1001
            10             X                  1010
    """

    roman_dict = {
        1: "I", 2: "II", 3: "III", 4: "IV", 5: "V",
        6: "VI", 7: "VII", 8: "VIII", 9: "IX", 10: "X"
    }
    binary_dict = {
        1: "1", 2: "10", 3: "11", 4: "100", 5: "101",
        6: "110", 7: "111", 8: "1000", 9: "1001", 10: "1010"
    }
    
    
    valid_input = False
    while not valid_input:
        user_input = input("Enter a number between 1 and 10: ")
        try:
            number = int(user_input)
            if 1 <= number <= 10:
                valid_input = True
            else:
                print("Error: The number must be between 1 and 10. Please try again.")
        except ValueError:
            print("Error: Invalid input. Please enter an integer.")


    print("Roman Numeral:", roman_dict[number])
    print("Binary Value:", binary_dict[number])
    print()  

def show_population():
    """
    Predicts and displays the growth of a population of organisms.
    It prompts the user for:
      - Starting number of organisms (non-negative)
      - Average daily increase (as a percentage, between 1 and 100)
      - Number of days to multiply (between 2 and 30)
    
    The program validates each input (rejecting non-numeric or out-of-range values)
    and then prints a table showing the population for each day.
    The population is calculated using the formula:
        new_population = current_population * (1 + daily_increase/100)
    The result is formatted to 2 decimal places.
    """

    valid = False
    while not valid:
        try:
            start_input = input("Enter the starting number of organisms: ")
            starting_population = float(start_input)
            if starting_population < 0:
                print("Error: Starting number cannot be negative. Please try again.")
            else:
                valid = True
        except ValueError:
            print("Error: Please enter a valid number.")

    valid = False
    while not valid:
        try:
            increase_input = input("Enter the average daily increase (as a percentage): ")
            daily_increase = float(increase_input)
            if daily_increase < 1 or daily_increase > 100:
                print("Error: Average daily increase must be between 1 and 100. Please try again.")
            else:
                valid = True
        except ValueError:
            print("Error: Please enter a valid number.")

   
    valid = False
    while not valid:
        try:
            days_input = input("Enter the number of days the organisms will multiply: ")
            num_days = int(days_input)
            if num_days < 2 or num_days > 30:
                print("Error: Number of days must be between 2 and 30. Please try again.")
            else:
                valid = True
        except ValueError:
            print("Error: Please enter a valid integer.")

   
    print("\nDay\tApproximate Population")
    population = starting_population
    for day in range(1, num_days + 1):
        print(f"{day}\t{population:.2f}")
        population = population * (1 + daily_increase / 100)
    print()  

def main():
    """
    Displays the main menu and processes user selections.
    The menu options are:
      1 - Display Student Information
      2 - Display Roman Numerals and Binary for a number (1-10)
      3 - Predict Population Growth
      9 - Exit the program
    The menu loops back after each valid option until the user selects 9 to exit.
    """
    option = 0
    while option != 9:
       
        print("Welcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals / Binary and Predict Population.")
        print("Enter option 1 to display Student Information.")
        print("Enter option 2 to display Roman Numerals and Binary.")
        print("Enter option 3 to Predict the Population.")
        print("Enter option 9 to Exit the program.")
        
        
        try:
            option = int(input("Enter your option: "))
        except ValueError:
            print("Error: Please enter a valid integer for the option.\n")
            continue

      
        if option == 1:
            show_student_information()
        elif option == 2:
            show_roman_binary_number()
        elif option == 3:
            show_population()
        elif option == 9:
            print("Exiting program. Goodbye!")
        else:
            print("Error: Invalid option. Please select one of the available menu options.\n")


main()
