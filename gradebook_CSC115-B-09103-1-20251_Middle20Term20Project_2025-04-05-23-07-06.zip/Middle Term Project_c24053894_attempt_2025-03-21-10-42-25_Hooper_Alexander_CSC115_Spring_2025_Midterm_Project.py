# Function to show email, major, course and semester of student
def show_student_information():
    # Header formatting for section
    print(" " * 20 + "STUDENT INFORMATION")
    print("*" * 60)
    # Print Student Information
    print("""       Name:    Alex Hooper
      Email:    axh2334@miami.edu
      Major:    Theatre Design & Technology
Course Name:    CSC115 - Intro to Python Programming
   Semester:    Spring 2025""")
    # Add newlines to break up next part of program
    print("\n\n")


# Function to show the corresponding roman numeral and binary number for any number from 1-10
def show_roman_binary_number():
    # Header formatting for section
    print(" " * 12 + "SHOW ROMAN NUMERAL AND BINARY NUMBER")
    print("*" * 60)
    # Ask user first time
    romain_binary_user_input = input("Enter a number 1-10: ")
    # Input & validation - check input and reselect if needed
    while not 1 <= int(romain_binary_user_input) <= 10:
        romain_binary_user_input = input("Invalid input. Enter a number 1-10: ")
    # Define lists to associate number with correct roman numeral/binary
    roman_numbers_1_10 = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    binary_numbers_1_10 = ["1", "10", "11", "100", "101", "101", "110", "111", "1000", "1001", "1010"]
    # Adjust user input to account for list indexing start at 0
    romain_binary_user_input_adjusted = int(romain_binary_user_input) - 1
    # Print title
    print(f"The number {romain_binary_user_input} in roman numerals and binary is:")
    # Print roman numeral with proper indentation
    print(f"\tRoman Numerals: {roman_numbers_1_10[romain_binary_user_input_adjusted]}")
    # Print binary with proper indentation
    print(f"\t\t\tBinary: {binary_numbers_1_10[romain_binary_user_input_adjusted]}")


# Function to show population multiplication over a certain number of days
def show_population():
    # Header for section
    print(" " * 8 + "CALCULATE POPULATION OVER THE COURSE OF TIME")
    print("*" * 60)
    # Enter number of organisms - initial input
    num_organisms = int(input("Enter the starting number of organisms: "))
    # Validate input; if less than 1, continue prompting user to enter number of organisms
    while num_organisms < 1:
        num_organisms = int(input("Invalid input. Starting organisms must be a positive number. Enter the starting number of organisms: "))

    # Enter percentage growth per day-initial input
    avg_daily_increase = int(input('Enter the percentage at which the organisms will multiply each day: '))
    # Validate input; if percentage not between 1-100, continue prompting user to enter percentage increase for day
    while not 1 <= avg_daily_increase <= 100:
        avg_daily_increase = int(input('Invalid input. Enter a number from 1-100 at which the organisms will multiply each day: ')) * 0.1

    # Enter days of growth - initial input
    days_to_multiply = int(input("Enter the number of days for which the organisms will multiply: "))
    # Validate input; if days not between 2 and 30, continue prompting user to enter days of multiplication
    while not 2 <= days_to_multiply <= 30:
        days_to_multiply = int(input("Invalid input. The number of days must be 2-30. Enter the number of days for which the organisms will multiply: "))

    # Output header
    print("Day Number\t\tPopulation")
    print("-"*30)

    # Output
    # Start loop at 1 instead of 0 to provide accurate human-readable counting
    for i in range(1, days_to_multiply + 1):
        # Print output with appropiate spacing to line up titles with data beaneath
        print(f"{i}.\t\t\t\t{num_organisms:.2f}")
        # Multiple number of organisms by itself + percentage daily increase.
        num_organisms *= ((1 + avg_daily_increase) * 0.1)


def main():
    # Header
    print("Welcome to the CSC115 Midterm Project Program.\n")
    print("This Python program displays Roman Numerals/Binary and Predict Population.")

    # Start with out-of-bounds option selection to begin validation loop
    option_selection = ""
    # Start validation loop; if 9, exit loop/function
    while option_selection != "9":
        print("""
    Enter option 1 to display Student Information. 
    Enter option 2 to display Roman Numerals and Binary.
    Enter option 3 to Predict the Population.
    Enter option 9 to exit the program.
    """)
        option_selection = input("Enter an option from the provided choices: ")
        # New lines to seperate next part of program
        print("\n\n")
        # Function calls for respective menu choices
        if option_selection == "1":
            show_student_information()
        if option_selection == "2":
            show_roman_binary_number()
        if option_selection == "3":
            show_population()

# Call main function to start program
main()