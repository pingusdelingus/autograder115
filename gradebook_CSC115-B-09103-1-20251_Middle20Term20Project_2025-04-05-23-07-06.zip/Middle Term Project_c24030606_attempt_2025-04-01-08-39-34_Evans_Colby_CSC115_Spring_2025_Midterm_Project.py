def show_student_information():
    print("\nStudent Information:")
    print("Full Name: Colby Evans")
    print("Email: cje73@miami.edu")
    print("Major: Data Science & AI")
    print("Course: CSC115 - Python Programming for Everyone")
    print("Semester: Spring 2025\n")

def get_valid_number(prompt, condition):
    num = input(prompt)
    while not (num.isdigit() and condition(int(num))):
        print("Invalid input. Please try again.")
        num = input(prompt)
    return int(num)


def show_roman_binary_number():
    roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    num = get_valid_number("Enter a number (1-10) to convert to Roman and Binary: ", lambda x: 1 <= x <= 10)
    print(f"Roman Numeral: {roman_numerals[num - 1]}")
    print(f"Binary: {bin(num)[2:]}")
    print()


def show_population():
    start_population = get_valid_number("Enter the starting number of organisms: ", lambda x: x > 0)
    daily_increase = get_valid_number("Enter the average daily population increase (1-100%): ",
                                      lambda x: 1 <= x <= 100) / 100
    days = get_valid_number("Enter the number of days to multiply (2-30): ", lambda x: 2 <= x <= 30)

    print("\nDay\tApproximate Population")
    population = start_population
    for day in range(1, days + 1):
        print(f"{day}\t{population:.2f}")
        population += population * daily_increase
    print()


def display_menu():
    print("\nWelcome to the CSC115 Midterm Project Program.")
    print("This Python program displays Roman Numerals / Binary and Predict Population.")
    print("1 - Display Student Information")
    print("2 - Display Roman Numerals and Binary")
    print("3 - Predict the Population")
    print("9 - Exit the Program")


def main():
    option = ""
    options = {"1": show_student_information, "2": show_roman_binary_number, "3": show_population}

    while option != "9":
        display_menu()
        option = input("Enter your option: ")
        if option in options:
            options[option]()
        elif option == "9":
            print("Exiting the program. Goodbye!")
        else:
            print("Invalid option. Please try again.\n")


if __name__ == "__main__":
    main()
