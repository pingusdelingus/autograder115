#User Information
#When the user selects option 1 then the program displays: your full name, email, major, course
#name, and semester on the screen. Then it loops back and displays the original menu for the user to
#select the option.

def show_student_information():
    print("Elizabeth Buitrago, \neeb158@miami.edu, \nMajor: Interactive Media, \nCSC 115, \nSpring 2025")

#Roman Numerals & Binary Numbers
#The program should display the Roman numerals
#version of that number and display the Binary value.
def show_roman_binary_number():
    number = int(input("Enter a number within the range of 1 to 10: "))
    while number < 1 or number > 10:
        number = int(input("Enter a number within the range of 1 to 10: "))

    if number == 1:
        return "I 1"
    elif number == 2:
        return "II 10"
    elif number == 3:
        return "III 11"
    elif number == 4:
        return "IV 100"
    elif number == 5:
        return "V 101"
    elif number == 6:
        return "VI 110"
    elif number == 7:
        return "VII 111"
    elif number == 8:
        return "VIII 1000"
    elif number == 9:
        return "IX 1001"
    elif number == 10:
        return "X 1010"

#Population
#When you user select option 3. The program predicts the approximate size of a population of
#organisms. The program should ask the user to enter the starting number of organisms, the average
#daily population increase (as a percentage, for example, 30 means 30%), and the number of days the
#organisms will be left to multiply.

def show_population():
    organisms= float(input("Please input the number of Starting Organisms: "))
    while organisms<0:
        organisms = float(input("Invalid Input. Please re-enter the number of Starting Organisms: "))

    daily= int(input("Please input the Average Daily Increase input: "))
    while daily<1 or daily>100:
        daily = int(input("Invalid Input. Please re-enter the Average Daily Increase input: "))

    days = int(input("Please input the Number of days to multiply input: "))
    while days<2 or days>30:
        days = int(input("Invalid Input. Please re-enter the Number of days to multiply: "))

    for day in range(days):
        print(day+1, f"{organisms:.2f}")
        organisms = organisms + daily/100 * organisms


def main():
    choice = int(input("""Welcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals
/ Binary and Predict Population. Enter option 1 to display Student Information. Enter option 2 to
display Roman Numerals and Binary. Enter option 3 to Predict the Population. Enter option 9 to
Exit the program.: """))
    while choice != 9:
        if choice == 1:
            show_student_information()
        elif choice == 2:
            print(show_roman_binary_number())
        elif choice == 3:
            show_population()
        choice = int(input("""Welcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals
        / Binary and Predict Population. Enter option 1 to display Student Information. Enter option 2 to
        display Roman Numerals and Binary. Enter option 3 to Predict the Population. Enter option 9 to
        Exit the program.: """))
main()



