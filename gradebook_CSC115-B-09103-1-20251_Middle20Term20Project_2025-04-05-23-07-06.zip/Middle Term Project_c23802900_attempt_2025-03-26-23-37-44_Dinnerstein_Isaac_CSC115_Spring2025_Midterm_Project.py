def show_student_information():
    print("Full Name: Isaac Dinnerstein")
    print("Email: ipd13@miami.edu")
    print("Major: International Studies, Political Science")
    print("Course: Python Programming is for Everyone")
    print("Semester: Spring 2025")
    print()

def main():
    while True:
        print("Isaac Dinnerstein's Python Midterm Project- Welcome")
        print("In this program, you can select student information, roman/binary numbers, predict the population, exit")
        print("Please input 1 for Student Information.")
        print("Please input 2 for Roman Numerals and Binary.")
        print("Please input 3 for the predicting the Population program.")
        print("Please input 9 to exit the program.")

        choice = input("Please select an option: ")

        if choice == "1":
            show_student_information()
        elif choice == "2":
            show_roman_binary_number()
        elif choice == "3":
            show_population()
        elif choice == "9":
            print("Exited, thank you")
            break
        else:
            print("This option is invalid")


def show_roman_binary_number():
    roman = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    binary = ["1", "10", "11", "100", "101", "110", "111", "1000", "1001", "1010"]

    while True:
        user_input = input("Please input a number between 1 and 10 ")
        try:
            num = float(user_input)
            if 1 <= num <= 10:
                num = int(num)
                print("Roman Numeral:", roman [num - 1])
                print("Binary Value:", binary [num - 1])
                break
            else:
                print("Please input a positive integer between 1 and 10")
        except:
            print("Please input a number")

def show_population():
    while True:
        user_input = input("Please input the starting population: ")
        try:
            start = float(user_input)
            if start > 0:
                break
            else:
                print("Please input a number greater than 0")
        except:
            print("This number is invalid\n")

    while True:
        user_input = input("Please input increase in percent between 1 and 100 ")
        try:
            increase = float(user_input)
            if 1 <= increase <= 100:
                break
            else:
                print("Error: Increase must be between 1 and 100 percent.\n")
        except:
            print("Error: Enter a valid number.\n")

    while True:
        user_input = input("Please input a number of days between 2 and 30 ")
        try:
            days = float(user_input)
            if 2 <= days <= 30:
                days = int(days)
                break
            else:
                print("Days must be integer between 2 and 30\n")
        except:
            print("Please input a valid number.\n")

    print("\nDay\tApproximate Population")
    for day in range(1, days + 1):
        print(f"{day}\t{start:.2f}")
        start += start * (increase / 100)
    print()



main()