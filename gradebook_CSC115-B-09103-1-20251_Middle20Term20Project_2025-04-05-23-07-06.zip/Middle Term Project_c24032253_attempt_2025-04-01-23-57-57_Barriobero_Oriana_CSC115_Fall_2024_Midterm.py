def show_student_information():
    print("Name: Oriana Barriobero\nEmail: idb36@miami.edu\nMajor: Computer Science\nCourse Name: CSC 115\nSemester: Spring 2025\n")
#The "show_student_information()" function displays the student's name, email, major, course name, and the current semester of enrollment. This function will only be called when the user enters option 2.

def show_roman_binary_number():
    roman_binary_number_input = float(input("Enter a number within the range of 1 and 10. No non-number inputs are allowed."))
    if roman_binary_number_input != int(roman_binary_number_input):
        print("The input is invalid. Only integer values 1-10 are valid.")
        show_roman_binary_number()
    else:
        roman_binary_number_list_index = int(roman_binary_number_input) - 1
        roman_list = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
        binary_list = [1, 10, 11, 100, 101, 110, 111, 1000, 1001, 1100]
        print("The Roman Numeral for", int(roman_binary_number_input), "is", roman_list[roman_binary_number_list_index],
              "and the binary value is", binary_list[roman_binary_number_list_index], ".")
        main()


#The "show_roman_binary_number()" function displays the Roman Number and Binary Number for an inputted value. This was done using lists and indices.
def show_population():
    def input_days():
        days = input('Enter the number of days the organisms will be left to multiply: ')
        return days
        input_increase()
    def input_increase():
        average_increase = float(input('Enter the average daily population increase percentage (only as the number itself): '))
        average_increase_decimal = average_increase / 100
        return average_increase_decimal
        input_organisms()
    def input_organisms():
        starting_organisms = int(input('Enter the starting number of organisms: '))

        if 1 <= starting_organisms <= 100:
            input_days()
        else:
            print('The value inputted for the organisms is invalid. Try again.')
        return starting_organisms
    days_0 = input_days()
    decimal_0 = input_increase()
    starting_organisms_0 = input_organisms()
    end_result = days_0 * decimal_0 * starting_organisms_0
    print(end_result)









def main():
    main_input = input("Welcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals / Binary and Predict Population.\nEnter option 1 to display Student Information.\nEnter option 2 to display Roman Numerals and Binary.\nEnter option 3 to Predict the Population.\nEnter option 9 to Exit the Program.\n")

    if main_input == str(1):
        show_student_information()
        main()
    elif main_input == str(2):
        show_roman_binary_number()
    elif main_input == str(3):
        show_population()
    elif main_input == str(9):
        return
    else:
        print("The input is invalid. Accepted values are '1', '2', '3', and '9'.\n")
        main()


#The "main()" function displays the welcome message and asks for the user's input.
main()

