# Catherine Arnold
# CSC115-B - Python Programming for Everyone (Spring 2025)
# Middle Term Project

# Function to display student information (full name, email, major, course, semester) at the start of the program
def show_student_information():
    print("\nStudent Information:")
    print("Name: Catherine Arnold")
    print("Email: catherinearnold@miami.edu")
    print("Major: Mathematics, Entrepreneurship, Finance, Spanish")
    print("Course: CSC115")
    print("Semester(Current): Spring 2025\n")

# Function to display the Roman numeral and binary representation of a number
def show_roman_binary_number():
    # Lists to map numbers to Roman numerals and binary values
    roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    binary_values = ["1", "10", "11", "100", "101", "110", "111", "1000", "1001", "1010"]

    # Variable to store user input, initialized to 0 (outside valid range)
    number = 0

    # Loop to validate user input (must be between 1 and 10)
    while not (1 <= number <= 10):
        try:
            number = int(input("\nEnter a number (1-10) to see its Roman numeral and binary representation: "))
            if not (1 <= number <= 10):
                print("Invalid input. Please enter a number between 1 and 10.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    # Output the Roman numeral and binary value for the valid input
    print(f"Roman Numeral: {roman_numerals[number - 1]}, Binary: {binary_values[number - 1]}\n")

# Function to calculate and display population growth
def show_population():
    # Prompt user for starting population (must be greater than 0)
    start_population = -1
    while start_population <= 0:
        try:
            start_population = int(input("\nEnter the starting number of organisms: "))
            print ("-" * 40) # Dashed line for separation
            if start_population <= 0:
                print("Invalid input. The starting number must be greater than 0.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    # Prompt user for daily percentage increase (must be between 1 and 100)
    daily_increase = 0
    while not (1 <= daily_increase <= 100):
        try:
            daily_increase = float(input("Enter the average daily increase (1-100%): "))
            print ("-" * 40) # Dashed line for separation
            if not (1 <= daily_increase <= 100):
                print("Invalid input. Please enter a percentage between 1 and 100.")
        except ValueError:
            print("Invalid input. Please enter a valid percentage.")

    # Prompt user for the number of days to multiply (must be between 2 and 30)
    days = 0
    while not (2 <= days <= 30):
        try:
            days = int(input("Enter the number of days to multiply (2-30): "))
            print ("-" * 40) # Dashed line for separation
            if not (2 <= days <= 30):
                print("Invalid input. Please enter a number of days between 2 and 30.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    # Display the table header
    print("\nDay\tApproximate Population")
    print("--------------------------------")

    #Initialize variables for the population growth calculation
    population = start_population
    total_population = 0 # Tracks cumulative population for average calculation

    # Loop through each day and calculate the population growth
    for day in range(1, days + 1):
        print(f"{day}\t{population:.2f}") # Display the day and population
        total_population += population # Add the population of the day to the total
        population += population * (daily_increase / 100) # Update population with daily increase

    # Calculate the average daily increase and display it
    average_increase = (total_population - start_population) / days
    print(f"\nThe average daily increase over {days} days is {average_increase:.2f}.")

# Main function to display the menu and handle user choices
def main():
    # Variable to store the user's menu choice
    choice = ""

    # Loop to display the menu until the user chooses to exit (option 9)
    while choice != "9":
        print("\nWelcome to the CSC115 Midterm Project Program.")
        print("This Python program displays Roman Numerals / Binary and Predicts Population.")
        print("Enter option 1 to display Student Information.")
        print("Enter option 2 to display Roman Numerals and Binary.")
        print("Enter option 3 to Predict the Population.")
        print("Enter option 9 to Exit the program.")

        # Get the user's menu choice
        choice = input("\nEnter your choice: ")

        # Handle the user's menu choice
        if choice == "1":
            show_student_information()
        elif choice == "2":
            show_roman_binary_number()
        elif choice == "3":
            show_population()
        elif choice == "9":
            print("Exiting the program. Thank you and Goodbye!")
        else:
            print("Invalid option. Please enter a valid choice.")

# Call the main function to start the program
main()
