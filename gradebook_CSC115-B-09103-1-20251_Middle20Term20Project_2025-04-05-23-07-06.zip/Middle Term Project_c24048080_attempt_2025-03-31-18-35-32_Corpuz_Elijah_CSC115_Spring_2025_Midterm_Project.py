#Student Information Function
def show_student_information():
    print("Name:Elijah Jeiden Corpuz\n"
          "Email:ejc236@miami.edu\n"
          "Major:Computer Science\n"
          "Course Name:CSC 115\n"
          "Semester:Spring 2025")

#Roman Numeral Function
def romanNumeral(number):
    if number == 1:
        return 'I'
    elif number == 2:
        return 'II'
    elif number == 3:
        return 'III'
    elif number == 4:
        return 'IV'
    elif number == 5:
        return 'V'
    elif number == 6:
        return 'VI'
    elif number == 7:
        return 'VII'
    elif number == 8:
        return 'VIII'
    elif number == 9:
        return 'IX'
    elif number == 10:
        return 'X'

#Binary Number Function
def binaryNumber(number):
    if number == 1:
        return '1'
    elif number == 2:
        return '10'
    elif number == 3:
        return '11'
    elif number == 4:
        return '100'
    elif number == 5:
        return '101'
    elif number == 6:
        return '110'
    elif number == 7:
        return '111'
    elif number == 8:
        return '1000'
    elif number == 9:
        return '1001'
    elif number == 10:
        return '1010'

#Roman and Binary Function
def show_roman_binary_number():
    number = input("Enter a number from 1-10:")

    #Validation loop
    while (not number.isdigit() or int(number) <= 0 or int(number) > 10):
        number = input("Invalid Input. Please enter a valid number: ")

    number = int(number)
    roman = romanNumeral(number)
    binary = binaryNumber(number)
    print(f"Number:{number}")
    print(f'Roman Numeral:{roman}')
    print(f'Binary Value:{binary}')

#Population Function
def show_population():
    organisms = int(input("Starting number of organisms:"))
    while (organisms < 1):
        int(input("Invalid number. Enter a valid number:"))

    growthRate = float(input("Average daily increase (1%-100%):"))
    while (growthRate < 1 or growthRate > 100):
        float(input("Invalid average. Enter a valid average:"))

    days = int(input("Number of days to multiply (Between 2-30 days):"))
    while (days < 2 or days > 30):
        int(input("Invalid number of days. Enter valid number of days:"))

    print("\nDay Approximate Population")
    print("1. {:.2f}".format(organisms))

    population = organisms
    for day in range(2, days + 1):
        population += population * (growthRate / 100)
        print(f"{day}. {population:.2f}")

#Menu Function
def main():
    num = 0
    while (num != '9'):
        menu = (input("Welcome to the CSC115 Midterm Project Program. This Python program displays Roman Numerals/Binary and Predict Population.\n"
              "Enter option 1 to display Student Information.\n"
              "Enter option 2 to display Roman Numerals and Binary.\n"
              "Enter option 3 to Predict the Population.\n"
              "Enter option 9 to Exit the program\n"
                      "Enter choice:"))
        if menu == '1':
            show_student_information()
        elif menu == '2':
             show_roman_binary_number()
        elif menu == '3':
            show_population()
        elif menu == '9':
            print("Thank you for using this program!")
            break
        else:
            print("Invalid option. Please select a valid option.")

#Call the main function
main()
