def show_student_information():
    print("Student Information")
    print("Name: Enter your full name")
    print("Email: Eneter your email")
    print("Major: your major")
    print("Course: CSC115")
    print("Semester: Spring 2025")

def show_roman_binary_number():
    roman_numerals =["I","II","III","IV","V","VI","VII","VIII","IX","X"]
    binary_valued =["1","10","11","100","101","110","111","1000","1001","1010"]

    while True:
        try:
            num = int(input("Enter a number (1-10): "))
            if 1 <= num <=10:
                print(f"Roman Numeral: {roman_numerals[num-1]}")
                print(f"Binary Value: {binary_values[num - 1]}")
                break
            else:
                print("Error: Invalid input, Number must be between 1 and 10")

def show_population():
    while True:
        try:
            start_population = int(input("Enter starting number of organisms: "))
            if start_population > 0:
                break
            print("Error: must be greater than 0")
        except ValueError:
            print("Error: Invalid input. Enter a number between 1 and 100.")
    while True:
        try:
            days = int(input("Enter a number of days (2-30): "))
            if 2 <= days <= 30:
                break
            print("Error: Must be between 2 and 30.")
        except ValueError:
            print("Error: Invalid input. Enter a number between 2 and 30.")

    print("\nDay\tApproximate Population")
    population = start_population
    for day in range(1, days + 1):
        print(f"{day}\t{population:.2f}")
        population += population * (daily_increases / 100)

def main():
    while True:
        print("\nWelcome to the CSC115 Midterm Project Program")
        print("1 - Display Student Information")
        print("2 - convert to Roman Numerals & Binary")
        print("3 = Predict Population")
        print("9 - Exit")

        choice = input("Enter your option: ")

        if choice == "1":
            show_student_information()
        elif choice == "2":
            show_roman_binary_number()
        elif choice == "3":
            show_population()
        elif choice == "9":
            print("Exiting program!")
            break
        else:
            print("Invalid choice. Please select a valid option.")

if _name_ == "_main_":
    main()


