# Function to display student information
def show_student_information():
    # Displays the student information as required
    print("Name: Kate Crandall")
    print("Email: kmc415@miami.edu")
    print("Major: Political Science")
    print("Course: CSC115-B - Python Programming for Everyone")
    print("Semester: Spring 2025")

# Function to display Roman Numerals and Binary Values
def show_roman_binary_number():
    # Prompts the user to enter a number between 1 and 10, and displays its Roman numeral and binary value
    valid_input = False
    while not valid_input:
        try:
            number = int(input("Enter a number between 1 and 10: "))
            if 1 <= number <= 10:
                # Define Roman Numerals and Binary values for 1-10
                roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
                binary_values = ["1", "10", "11", "100", "101", "110", "111", "1000", "1001", "1010"]

                # Print function used to display the Roman numeral and binary value
                print(f"Roman Numeral: {roman_numerals[number - 1]}")
                print(f"Binary Value: {binary_values[number - 1]}")
                valid_input = True  # Exit loop on valid input
            else:
                print("Error: Please enter a number between 1 and 10.")
        except ValueError:
            print("Error: Invalid input. Please enter a valid number.")

# Function to calculate and display population over time
def show_population():
    # Prompts the user for starting population, daily increase, and number of days.
    # Calculates the population over time and displays the results.
    start_population = None
    while start_population is None:
        try:
            start_population = int(input("Enter starting number of organisms (positive integer): "))
            if start_population < 1:
                print("Error: The starting number of organisms must be a positive integer.")
                start_population = None  # Reset if invalid
        except ValueError:
            print("Error: Invalid input. Please enter a valid number for starting population.")

    daily_increase = None
    while daily_increase is None:
        try:
            daily_increase = int(input("Enter the average daily population increase (1-100 percent): "))
            if daily_increase < 1 or daily_increase > 100:
                print("Error: The daily increase must be between 1 and 100 percent.")
                daily_increase = None  # Reset if invalid
        except ValueError:
            print("Error: Invalid input. Please enter a valid number for daily increase.")

    num_days = None
    while num_days is None:
        try:
            num_days = int(input("Enter the number of days (between 2 and 30): "))
            if num_days < 2 or num_days > 30:
                print("Error: The number of days must be between 2 and 30.")
                num_days = None  # Reset if invalid
        except ValueError:
            print("Error: Invalid input. Please enter a valid number for days.")

    # Calculate and display population for each day
    print("\nDay\tApproximate Population")
    population = start_population
    for day in range(1, num_days + 1):
        print(f"{day}. {population:.2f}")
        population *= (1 + daily_increase / 100)

# Main function to display the menu and handle user selection
def main():
    # Main function that displays the menu and loops through the options until the user chooses to exit.
    while True:  # Infinite loop that only breaks if the user selects option 9
        print("\nWelcome to the CSC115 Midterm Project Program.")
        print("This Python program displays Roman Numerals / Binary and Predict Population.")
        print("Enter option 1 to display Student Information.")
        print("Enter option 2 to display Roman Numerals and Binary.")
        print("Enter option 3 to Predict the Population.")
        print("Enter option 9 to Exit the program.")

        try:
            option = int(input("Please select an option: "))
            if option == 1:
                show_student_information()
            elif option == 2:
                show_roman_binary_number()
            elif option == 3:
                show_population()
            elif option == 9:
                print("Exiting the program...")
                break  # Breaks out of the loop to exit the program
            else:
                print("Error: Invalid option. Please choose a valid option between 1-3 or 9 to exit.")
        except ValueError:
            print("Error: Invalid input. Please enter a number between 1 and 9.")

# Call the main function to start the program
if __name__ == "__main__":
    main()