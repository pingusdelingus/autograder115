
# OPTION1 Student Information
def show_student_information():
    print("\nStudent Information:")
    print("Full Name: Faris Mazen Daoud")
    print("Email: fmd50@miami.edu")
    print("Major: Health Science")
    print("Course Name: CSC 115 Python Programming for Everyone")
    print("Semester: Spring 2025")

show_student_information()

# OPTION2 Roman Binary Numerals
def show_roman_binary_number():
    print("")
    number = float(input("Please enter a number between 1 and 10: "))
    while number < 0 or number > 10:
        number = float(input("Invalid input. Number must be between 1 and 10: "))
    print(f"The number is {number}")


# IF statement that assigns a number with a roman numeral
    if(number == 1):
        roman_numeral_value = "I"
    elif(number == 2):
        roman_numeral_value = "II"
    elif(number == 3):
        roman_numeral_value = "III"
    elif(number == 4):
        roman_numeral_value = "IV"
    elif(number == 5):
        roman_numeral_value = "V"
    elif(number == 6):
        roman_numeral_value = "VI"
    elif(number == 7):
        roman_numeral_value = "VII"
    elif(number == 8):
        roman_numeral_value = "VIII"
    elif(number == 9):
        roman_numeral_value = "IX"
    else:
        roman_numeral_value = "X"

# Displays a chart for numbers 1-10, their roman numeral, and their binary number
    print(f"You entered {number}")
    print(f"{'Input number': <10} {'Roman numeral': ^20} {"Binary Value": >15}")
    print(f"{number: ^10} {roman_numeral_value: ^20} \t\t{int(number): b}")


# OPTION3 Population Prediction
def show_population():
    print("\nPopulation Prediction")

# Validating the starting number of organisms
    starting_number_of_organisms = float(input("\nPlease enter a number of starting organisms:"))
    while starting_number_of_organisms < 0:
        starting_number_of_organisms = float(input("Invalid Input. Please re enter the number:"))
        starting_number_of_organisms = float(starting_number_of_organisms)

# Validating the average increase in daily population increase
    average_increase = float(input("\nPlease enter the average daily population increase percentage:"))
    while average_increase < 1 or average_increase > 100:
        average_increase = float(input("Invalid Input. Please re enter a number between 1 and 100 as a percentage:"))
        average_increase = float(average_increase)

# Validating the number of days the organisms will multiply
    number_of_days = int(input("\nPlease enter the number of days that the organisms will multiply: "))
    while number_of_days <= 2 or number_of_days >= 30:
       print("Invalid input. Please re enter the number of days between 2 and 30: ")
       number_of_days = int(input("number_of_days"))

# This section of code displays a chart of the number of days and population prediction
    print("\nDay\t        Population Prediction")
    print("------------------------------------------------")
    predicted_population = starting_number_of_organisms
    for day in range(1,number_of_days + 1):
        print(f"{day}.\t               {predicted_population:.2f}")
        predicted_population += predicted_population * (average_increase / 100)
    print()
    print("------------------------------------------------")

# Main Function/ Implementing the main function and menu
def main():
     print("Welcome to CSC 115 Spring 2025 Midterm Project.\nThis Python Program Displays Roman Numerals/Binary and Predicts Populaton")
     print("\nEnter option 1 to display Student Information")
     print("Enter option 2 to display Roman Binary Numbers")
     print("Enter option 3 to display Population Prediction")
     print("Enter option 9 to Exit the Program.")

# Selection of the menu items/Loop for invalid number or menu selection after valid options
     userInputSelection = input("\nEnter 1 of the 4 choices from the menu: ")
     while (userInputSelection != "9"):

         if (userInputSelection == "1"):
             show_student_information()

         elif (userInputSelection == "2"):
             show_roman_binary_number()

         elif (userInputSelection == "3"):
             show_population()
         else:
             print(f"Sorry, please choose another number")
         userInputSelection = input("\nEnter 1 of the 4 choices from the menu: 1")
         print("Thank you, lets move on to the next section!")

if __name__ =="__main__":
    main()