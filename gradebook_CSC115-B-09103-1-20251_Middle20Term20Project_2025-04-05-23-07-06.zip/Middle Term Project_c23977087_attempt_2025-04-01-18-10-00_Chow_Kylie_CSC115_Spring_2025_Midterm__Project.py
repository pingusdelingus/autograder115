# Function to display student information
def show_student_information():
    print("Full Name: Kylie Chow")
    print("Email: @kac436@miami.edu ")
    print("Major: Data Science and Artificial Intelligence")
    print("Course: CSC115")
    print("Semester: Spring 2025")


# Function to display Roman Numerals and Binary Numbers
def show_roman_binary_number():
    number = 0  # Initialize number
    while not (1 <= number <= 10):  # Keep asking until valid input is given
        try:
            number = int(input("Enter a number between 1 and 10: "))
            if not (1 <= number <= 10):
                print("Error: The number must be between 1 and 10.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    binary_values = ["1", "10", "11", "100", "101", "110", "111", "1000", "1001", "1010"]

    print(f"Roman Numeral: {roman_numerals[number - 1]}")
    print(f"Binary Value: {binary_values[number - 1]}")


# Function to predict the population
def show_population():
    starting_number = -1  # Start with an invalid value
    while starting_number < 0:
        try:
            starting_number = int(input("Enter the starting number of organisms (>= 0): "))
            if starting_number < 0:
                print("Error: The starting number cannot be negative.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    daily_increase = 0
    while not (1 <= daily_increase <= 100):
        try:
            daily_increase = int(input("Enter the average daily increase as a percentage (1-100): "))
            if not (1 <= daily_increase <= 100):
                print("Error: The average daily increase must be between 1 and 100.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    days = 0
    while not (2 <= days <= 30):
        try:
            days = int(input("Enter the number of days (2-30): "))
            if not (2 <= days <= 30):
                print("Error: The number of days must be between 2 and 30.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    print("\nDay    Approximate Population")
    for day in range(1, days + 1):
        population = starting_number * ((1 + daily_increase / 100) ** day)
        print(f"{day}     {population:.2f}")


# Main function to control the menu and loop
def main():
    choice = 0  # Initialize choice
    while choice != 9:
        print("\nWelcome to the CSC115 Midterm Project Program.")
        print("This Python program displays Roman Numerals / Binary and Predict Population.")
        print("Enter option 1 to display Student Information.")
        print("Enter option 2 to display Roman Numerals and Binary.")
        print("Enter option 3 to Predict the Population.")
        print("Enter option 9 to Exit the program.")

        try:
            choice = int(input("Please select an option (1, 2, 3, 9): "))
            if choice == 1:
                show_student_information()
            elif choice == 2:
                show_roman_binary_number()
            elif choice == 3:
                show_population()
            elif choice == 9:
                print("Exiting program.")
            else:
                print("Invalid option. Please try again.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")


# Calling the main function to start the program
if __name__ == "__main__":
    main()
