# CSC115 Midterm Project
#Eduardo Alcofra Tocantins
#C24116670

def show_student_information():
    # This function displays the student's info on separate lines.
    # It's straightforward: each print is a different piece of info.
    print("Eduardo Alcofra Tocantins")
    print("exa1127@miami.edu")
    print("Economics")
    print("Python for Everyone")
    print("Fall 2024")


def show_roman_binary_number():
    #There are two lists: one for Roman numerals, one for Binary
    #Each list has 10 elements, corresponding to numbers 1 to 10
    roman_list = ["I", "II", "III", "IV", "V",
                  "VI", "VII", "VIII", "IX", "X"]  #indexes: 0 to 9
    binary_list = ["1", "10", "11", "100", "101",
                   "110", "111", "1000", "1001", "1010"]  #indexes: 0 to 9

    user_input = input("\nEnter a number (1..10): ")  # ask user for a number from 1 to 10

    # Validate input: must be digit and between 1 and 10 inclusive
    while not user_input.isdigit() or not (1 <= int(user_input) <= 10):
        print("Invalid input. Please enter a number between 1 and 10.")
        user_input = input("Re-enter (1..10): ")

    num = int(user_input)  #convert the valid input to int

    # We print the matching Roman numeral and Binary value
    # The index is num-1, because lists are zero-based
    print(f"Roman Numeral for {num}: {roman_list[num - 1]}")
    print(f"Binary for {num}      : {binary_list[num - 1]}")



def show_population():
    #This function calculates population growth based on user inputs
    start_str = input("\nEnter the starting number of organisms (>0): ")
    while not start_str.isdigit() or int(start_str) < 1:
        print("Invalid input! Must be a positive integer (>0).")
        start_str = input("Please enter again: ")
    start_organisms = int(start_str)

    increase_str = input("Enter the average daily increase (1..100): ")
    while not increase_str.isdigit() or not (1 <= int(increase_str) <= 100):
        print("Invalid input! Must be between 1 and 100.")
        increase_str = input("Enter daily increase again: ")
    daily_increase = int(increase_str)

    days_str = input("Enter how many days (2..30): ")
    while not days_str.isdigit() or not (2 <= int(days_str) <= 30):
        print("Invalid input! Must be in the 2..30 range.")
        days_str = input("Re-enter the number of days: ")
    days = int(days_str)

    # Print a header for the results
    print("\nDay   Approximate Population")

    population = float(start_organisms)
    for day in range(1, days + 1):
        # left-align the day in width 5, right-align population with 2 decimal places
        print(f"{day:<5} {population:>10.2f}")
        population *= (1 + daily_increase / 100.0)

    print()  # a blank line at the end



def main():
    option = 0  # It keep looping until the user chooses 9

    while option != 9:
        # Just show the menu each loop iteration
        print("\nWelcome to the CSC115 Midterm Project Program.")
        print("This Python program displays Roman Numerals / Binary and Predict Population.")
        print("Enter 1: Display Student Information")
        print("Enter 2: Display Roman Numerals and Binary")
        print("Enter 3: Predict the Population")
        print("Enter 9: Exit the program")

        choice_str = input("Please select an option: ")

        if not choice_str.isdigit():
            # if user typed something that's not digits, inform them and skip
            print("Invalid menu selection! Must be 1, 2, 3, or 9.")
            continue

        option = int(choice_str)

        if option == 1:
            show_student_information()
        elif option == 2:
            show_roman_binary_number()
        elif option == 3:
            show_population()
        elif option == 9:
            # if user picks 9, interrupt the loop
            print("See you later!")
        else:
            print("Invalid menu selection! Must be 1, 2, 3, or 9.")

# main function is used so the program can run right away
main()
