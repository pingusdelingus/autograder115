def show_student_information():  # Display student info
    print("Name: Caroline Crawford")
    print("Email: cnc920@miami.edu")
    print("Major: ECS")
    print("Course: CSC115")
    print("Semester: Spring 2025")


def input_validation(min_value, max_value):  # Validate input to check its an integer and within the range()
    num = None
    while num is None:
        value = input()
        if value:
            try:
                value = int(value)
                if min_value <= value <= max_value:
                    num = value
                else:
                    print(f"Error: Enter a number between {min_value} and {max_value}.")
            except ValueError:
                print("Error: Invalid input. Please enter a number.")
    return num


def show_roman_binary_number():  # Convert numbers to Roman numerals and binary
    roman_numerals = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    binary_values = ["1", "10", "11", "100", "101", "110", "111", "1000", "1001", "1010"]

    print("Enter a number from 1 to 10:")
    num = input_validation(1, 10)

    print(f"Roman Numeral: {roman_numerals[num-1]}")
    print(f"Binary Value: {binary_values[num-1]}")


def show_population():  # Calculate and display population growth
    print("Enter the starting number of organisms (positive number only):")
    start_population = input_validation(1, 10000000000000)

    print("Enter the average daily population increase (1-100%):")
    daily_increase = input_validation(1, 100)

    print("Enter the number of days to multiply (between 2 and 30):")
    days_to_multiply = input_validation(2, 30)

    population = float(start_population)
    for day in range(1, days_to_multiply + 1):
        print(f"{day} {population:.2f}")
        population = population * (daily_increase / 100)


def main():  # Display Main menu function
    option = None
    while option != "9":
        print("Welcome to the CSC115 Midterm Project Program")
        print("1 - Display Student Information")
        print("2 - Convert to Roman Numerals & Binary")
        print("3 - Predict Population Growth")
        print("9 - Exit Program")

        option = input()

        if option == "1":
            show_student_information()
        elif option == "2":
            show_roman_binary_number()
        elif option == "3":
            show_population()
        elif option == "9":
            print("Exiting program. Goodbye!")
        else:
            print("Error: Invalid choice. Please select a valid option.")


if __name__ == "__main__":
    main()
